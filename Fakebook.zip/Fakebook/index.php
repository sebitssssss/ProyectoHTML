<?php
// Cada vez que entrás a localhost/Fakebook se cierra la sesión anterior y te manda al login
session_start();
session_destroy();
header("Location: login/login.php");
exit;
?>
