<?php
include "../conexion.php";

$msg = "";

// Cuando se aprieta "Crear cuenta"
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $nombre = trim($_POST["nombre"]);
    $clave = $_POST["clave"];
    $clave2 = $_POST["clave2"];
    $nacimiento = $_POST["nacimiento"];
    $pais = $_POST["pais"];

    // Si no puso fecha de nacimiento la guardamos vacía (NULL)
    if ($nacimiento == "") {
        $nacimiento = null;
    }

    // Revisamos si el email o el nombre de usuario ya existen
    $st = $con->prepare("SELECT COUNT(*) FROM Usuarios WHERE Usuarios.Email = ?");
    $st->bind_param("s", $email);
    $st->execute();
    $st->bind_result($emailUsado);
    $st->fetch();
    $st->close();

    $st = $con->prepare("SELECT COUNT(*) FROM Perfiles WHERE Perfiles.NombreUsuario = ?");
    $st->bind_param("s", $nombre);
    $st->execute();
    $st->bind_result($nombreUsado);
    $st->fetch();
    $st->close();

    // Validaciones
    if ($emailUsado > 0) {
        $msg = "Ese email ya está registrado.";
    } elseif ($nombreUsado > 0) {
        $msg = "Ese nombre de usuario ya existe.";
    } elseif (strlen($nombre) < 3) {
        $msg = "El nombre de usuario tiene que tener al menos 3 caracteres.";
    } elseif (strlen($clave) < 8) {
        $msg = "La contraseña tiene que tener mínimo 8 caracteres.";
    } elseif ($clave != $clave2) {
        $msg = "Las contraseñas no coinciden.";
    } else {
        // Guardamos el usuario con la contraseña encriptada
        $hash = password_hash($clave, PASSWORD_DEFAULT);
        $hoy = date("Y-m-d");

        $st = $con->prepare("INSERT INTO Usuarios (Email, `Contraseña`, FechaRegistro, Estado) VALUES (?, ?, ?, 'Activo')");
        $st->bind_param("sss", $email, $hash, $hoy);
        $st->execute();
        $idNuevo = $con->insert_id;
        $st->close();

        // Y le creamos el perfil con el nombre de usuario
        $st = $con->prepare("INSERT INTO Perfiles (ID_Usuario, ID_Pais, NombreUsuario, FechaNacimiento) VALUES (?, ?, ?, ?)");
        $st->bind_param("iiss", $idNuevo, $pais, $nombre, $nacimiento);
        $st->execute();
        $st->close();

        header("Location: ../login/login.php?registrado=1");
        exit;
    }
}

// Traemos los países para el desplegable
$paises = $con->query("SELECT Paises.ID_Pais, Paises.Nombre FROM Paises ORDER BY Paises.Nombre");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Crear cuenta - Fakebook</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="../general/general.css">
  <link rel="stylesheet" href="registro.css">
</head>
<body>

  <div class="container-fluid p-0">
    <div class="row g-0 pantalla-completa">

      <!-- Lado izquierdo: foto con la frase -->
      <div class="col-md-6 d-none d-md-flex portada-login text-white p-5 flex-column justify-content-end">
        <h1 class="fw-bold">La vida es mejor cuando la compartís.</h1>
        <p class="text-white-50">Conectá con tus amigos, descubrí nuevas personas y compartí lo que te inspira.</p>
      </div>

      <!-- Lado derecho: formulario de registro -->
      <div class="col-md-6 d-flex align-items-center justify-content-center p-4 bg-white">
        <div class="caja-form">
          <span class="logo"><i class="bi bi-triangle-fill"></i></span>
          <h2 class="fw-bold fs-4 mt-4 mb-1">Tu próxima conexión empieza acá</h2>
          <p class="text-muted small mb-4">Creá tu cuenta. Es simple, gratis y a tu ritmo.</p>

          <?php if ($msg != "") { ?>
            <div class="alert alert-danger small py-2"><?php echo $msg; ?></div>
          <?php } ?>

          <form method="post">
            <div class="mb-3">
              <label class="form-label small fw-semibold">Email</label>
              <input type="email" class="form-control" name="email" maxlength="100" required>
            </div>
            <div class="mb-3">
              <label class="form-label small fw-semibold">Nombre de usuario</label>
              <input type="text" class="form-control" name="nombre" maxlength="30" required>
            </div>

            <!-- Contraseña y repetir contraseña, una al lado de la otra -->
            <div class="row g-2 mb-3">
              <div class="col-sm-6">
                <label class="form-label small fw-semibold">Contraseña</label>
                <input type="password" class="form-control" name="clave" required>
              </div>
              <div class="col-sm-6">
                <label class="form-label small fw-semibold">Repetir contraseña</label>
                <input type="password" class="form-control" name="clave2" required>
              </div>
            </div>

            <div class="row g-2 mb-4">
              <div class="col-sm-6">
                <label class="form-label small fw-semibold">Fecha de nacimiento</label>
                <input type="date" class="form-control" name="nacimiento">
              </div>
              <div class="col-sm-6">
                <label class="form-label small fw-semibold">País</label>
                <select class="form-select" name="pais">
                  <?php while ($pais = $paises->fetch_assoc()) { ?>
                    <option value="<?php echo $pais["ID_Pais"]; ?>"><?php echo $pais["Nombre"]; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold mb-3">Crear cuenta</button>
          </form>

          <p class="text-center small mb-0">
            ¿Ya tenés cuenta? <a href="../login/login.php" class="fw-semibold">Ingresar</a>
          </p>
        </div>
      </div>

    </div>
  </div>

</body>
</html>
