<?php
include "../general/sesion.php";

// Si viene ?con=ID es porque quiere hablar con ese amigo
if (isset($_GET["con"])) {
    $otro = $_GET["con"];

    // Buscamos si ya existe un chat entre los dos
    $st = $con->prepare("SELECT Chats.ID_Chat FROM Chats
        WHERE (Chats.ID_UsuarioE = ? AND Chats.ID_UsuarioR = ?) OR (Chats.ID_UsuarioE = ? AND Chats.ID_UsuarioR = ?)");
    $st->bind_param("iiii", $yo, $otro, $otro, $yo);
    $st->execute();
    $st->bind_result($idChat);
    $existe = $st->fetch();
    $st->close();

    // Si no existe lo creamos, pero solo si son amigos
    if (!$existe) {
        $st = $con->prepare("SELECT COUNT(*) FROM Amigos WHERE Amigos.Estado = 'Aceptado'
            AND ((Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?) OR (Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?))");
        $st->bind_param("iiii", $yo, $otro, $otro, $yo);
        $st->execute();
        $st->bind_result($sonAmigos);
        $st->fetch();
        $st->close();

        if ($sonAmigos == 0) {
            header("Location: mensajes.php");
            exit;
        }

        $hoy = date("Y-m-d");
        $st = $con->prepare("INSERT INTO Chats (ID_UsuarioE, ID_UsuarioR, FechaCreacion) VALUES (?, ?, ?)");
        $st->bind_param("iis", $yo, $otro, $hoy);
        $st->execute();
        $idChat = $con->insert_id;
        $st->close();
    }

    header("Location: mensajes.php?chat=" . $idChat);
    exit;
}

// Chat que está abierto (si hay uno)
$idChat = 0;
if (isset($_GET["chat"])) {
    $idChat = $_GET["chat"];
}

$nombreOtro = "";
$fotoOtro = "";

if ($idChat != 0) {
    // Buscamos con quién es el chat, y de paso revisamos que yo esté en ese chat
    $st = $con->prepare("SELECT Perfiles.NombreUsuario, FotoPerfil.URL
        FROM Chats
        JOIN Perfiles ON (Perfiles.ID_Usuario = Chats.ID_UsuarioR AND Chats.ID_UsuarioE = ?)
                      OR (Perfiles.ID_Usuario = Chats.ID_UsuarioE AND Chats.ID_UsuarioR = ?)
        LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
        WHERE Chats.ID_Chat = ?");
    $st->bind_param("iii", $yo, $yo, $idChat);
    $st->execute();
    $st->bind_result($nombreOtro, $fotoOtro);
    $esMio = $st->fetch();
    $st->close();

    if (!$esMio) {
        header("Location: mensajes.php");
        exit;
    }

    // Mandar un mensaje
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $texto = trim($_POST["texto"]);
        if ($texto != "") {
            $fecha = date("Y-m-d H:i:s");
            $st = $con->prepare("INSERT INTO Mensajes (ID_Chat, ID_UsuarioEmisor, Texto, FechaEnvio, Leido) VALUES (?, ?, ?, ?, 0)");
            $st->bind_param("iiss", $idChat, $yo, $texto, $fecha);
            $st->execute();
            $st->close();
        }
        header("Location: mensajes.php?chat=" . $idChat . "#ultimo");
        exit;
    }

    // Como abrió el chat, marcamos como leídos los mensajes que le mandaron
    $st = $con->prepare("UPDATE Mensajes SET Mensajes.Leido = 1 WHERE Mensajes.ID_Chat = ? AND Mensajes.ID_UsuarioEmisor <> ?");
    $st->bind_param("ii", $idChat, $yo);
    $st->execute();
    $st->close();

    // Traemos los mensajes del chat
    $st = $con->prepare("SELECT Mensajes.ID_UsuarioEmisor, Mensajes.Texto, Mensajes.FechaEnvio FROM Mensajes WHERE Mensajes.ID_Chat = ? ORDER BY Mensajes.FechaEnvio");
    $st->bind_param("i", $idChat);
    $st->execute();
    $mensajes = $st->get_result();
}

// Lista de mis chats, con el último mensaje y cuántos no leí
$st = $con->prepare("SELECT Chats.ID_Chat, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto,
        (SELECT Mensajes.Texto FROM Mensajes WHERE Mensajes.ID_Chat = Chats.ID_Chat ORDER BY Mensajes.FechaEnvio DESC LIMIT 1) AS UltimoTexto,
        (SELECT MAX(Mensajes.FechaEnvio) FROM Mensajes WHERE Mensajes.ID_Chat = Chats.ID_Chat) AS UltimaFecha,
        (SELECT COUNT(*) FROM Mensajes WHERE Mensajes.ID_Chat = Chats.ID_Chat AND Mensajes.ID_UsuarioEmisor <> ? AND Mensajes.Leido = 0) AS NoLeidos
    FROM Chats
    JOIN Perfiles ON (Perfiles.ID_Usuario = Chats.ID_UsuarioR AND Chats.ID_UsuarioE = ?)
                  OR (Perfiles.ID_Usuario = Chats.ID_UsuarioE AND Chats.ID_UsuarioR = ?)
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    ORDER BY UltimaFecha DESC");
$st->bind_param("iii", $yo, $yo, $yo);
$st->execute();
$chats = $st->get_result();

// Mis amigos, para poder empezar una conversación nueva
$st = $con->prepare("SELECT Perfiles.ID_Usuario, Perfiles.NombreUsuario
    FROM Amigos
    JOIN Perfiles ON (Perfiles.ID_Usuario = Amigos.ID_UsuarioAmigo AND Amigos.ID_Usuario = ?)
                  OR (Perfiles.ID_Usuario = Amigos.ID_Usuario AND Amigos.ID_UsuarioAmigo = ?)
    WHERE Amigos.Estado = 'Aceptado'
    ORDER BY Perfiles.NombreUsuario");
$st->bind_param("ii", $yo, $yo);
$st->execute();
$amigos = $st->get_result();

$titulo = "Mensajes";
$css = "mensajes.css";
$activa = "mensajes";
include "../general/arriba.php";
?>

<h4 class="fw-bold mb-1">Mensajes</h4>
<p class="text-muted small mb-4">Tus conversaciones, todas en un mismo lugar.</p>

<div class="card border-0 shadow-sm overflow-hidden">
  <div class="row g-0">

    <!-- Columna de la izquierda: lista de chats -->
    <!-- En el celular, si hay un chat abierto se esconde la lista -->
    <div class="col-md-5 col-lg-4 border-end p-3 lista-chats <?php if ($idChat != 0) echo "d-none d-md-block"; ?>">

      <!-- Empezar una conversación nueva con un amigo -->
      <form method="get" class="d-flex gap-2 mb-3">
        <select class="form-select form-select-sm bg-light border-0" name="con" required>
          <option value="">Nueva conversación con...</option>
          <?php while ($amigo = $amigos->fetch_assoc()) { ?>
            <option value="<?php echo $amigo["ID_Usuario"]; ?>"><?php echo htmlspecialchars($amigo["NombreUsuario"]); ?></option>
          <?php } ?>
        </select>
        <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></button>
      </form>

      <?php if ($chats->num_rows == 0) { ?>
        <p class="text-muted small">Todavía no tenés conversaciones.</p>
      <?php } ?>

      <?php while ($chat = $chats->fetch_assoc()) { ?>
        <a href="mensajes.php?chat=<?php echo $chat["ID_Chat"]; ?>" class="chat-item <?php if ($chat["ID_Chat"] == $idChat) echo "abierto"; ?>">
          <?php mostrarAvatar($chat["Foto"], "md"); ?>
          <div class="chat-texto">
            <div class="d-flex justify-content-between gap-2">
              <span class="fw-semibold small text-truncate"><?php echo htmlspecialchars($chat["NombreUsuario"]); ?></span>
              <?php if ($chat["UltimaFecha"] != "") { ?>
                <small class="chat-hora"><?php echo date("d/m H:i", strtotime($chat["UltimaFecha"])); ?></small>
              <?php } ?>
            </div>
            <div class="d-flex justify-content-between align-items-center">
              <small class="text-muted text-truncate"><?php echo htmlspecialchars($chat["UltimoTexto"]); ?></small>
              <?php if ($chat["NoLeidos"] > 0) { ?>
                <span class="badge rounded-pill bg-primary ms-2"><?php echo $chat["NoLeidos"]; ?></span>
              <?php } ?>
            </div>
          </div>
        </a>
      <?php } ?>
    </div>

    <!-- Columna de la derecha: el chat abierto -->
    <div class="col-md-7 col-lg-8 flex-column chat <?php if ($idChat != 0) echo "d-flex"; else echo "d-none d-md-flex"; ?>">

      <?php if ($idChat == 0) { ?>
        <!-- Todavía no eligió ningún chat -->
        <div class="sin-chat">
          <i class="bi bi-chat-dots"></i>
          <p class="small mb-0">Elegí una conversación para empezar a chatear.</p>
        </div>
      <?php } else { ?>

        <!-- Arriba del chat: con quién estoy hablando -->
        <div class="d-flex align-items-center gap-2 p-3 border-bottom">
          <a href="mensajes.php" class="btn btn-sm btn-light d-md-none"><i class="bi bi-arrow-left"></i></a>
          <?php mostrarAvatar($fotoOtro, "sm"); ?>
          <span class="fw-semibold small"><?php echo htmlspecialchars($nombreOtro); ?></span>
        </div>

        <!-- Los mensajes -->
        <div class="caja-chat p-3">
          <?php if ($mensajes->num_rows == 0) { ?>
            <p class="text-center text-muted small">Todavía no hay mensajes. ¡Mandá el primero!</p>
          <?php } ?>

          <?php while ($mensaje = $mensajes->fetch_assoc()) { ?>
            <!-- Si lo mandé yo va a la derecha (enviado), si no a la izquierda (recibido) -->
            <div class="mensaje <?php if ($mensaje["ID_UsuarioEmisor"] == $yo) echo "enviado"; else echo "recibido"; ?>">
              <div class="burbuja"><?php echo htmlspecialchars($mensaje["Texto"]); ?></div>
              <small class="hora"><?php echo date("d/m H:i", strtotime($mensaje["FechaEnvio"])); ?></small>
            </div>
          <?php } ?>
          <div id="ultimo"></div>
        </div>

        <!-- Escribir un mensaje -->
        <form method="post" class="d-flex gap-2 p-3 border-top">
          <input type="text" class="form-control bg-light border-0" name="texto" maxlength="255" placeholder="Escribí un mensaje..." required autofocus>
          <button type="submit" class="btn btn-primary px-4">Enviar</button>
        </form>

      <?php } ?>
    </div>

  </div>
</div>

<?php include "../general/abajo.php"; ?>
