<?php
include "../general/sesion.php";

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Botón de Me gusta
    if ($_POST["accion"] == "like") {
        darLike($con, $yo, $_POST["id_publicacion"]);
        header("Location: inicio.php#post-" . $_POST["id_publicacion"]);
        exit;
    }

    // Botón de Publicar
    if ($_POST["accion"] == "publicar") {
        $texto = trim($_POST["texto"]);
        $privacidad = $_POST["privacidad"];
        $imagen = "";

        // Si eligió una foto la subimos
        if ($_FILES["foto"]["name"] != "") {
            $imagen = subirImagen($_FILES["foto"], "publicaciones");
            if ($imagen == "") {
                $msg = "La foto tiene que ser JPG o PNG y pesar menos de 5 MB.";
            }
        }

        if ($msg == "" && $texto == "" && $imagen == "") {
            $msg = "Escribí algo o subí una foto para publicar.";
        }

        if ($msg == "") {
            // Guardamos la publicación
            $fecha = date("Y-m-d H:i:s");
            $st = $con->prepare("INSERT INTO Publicaciones (ID_Usuario, Texto, FechaPublicacion, Privacidad) VALUES (?, ?, ?, ?)");
            $st->bind_param("isss", $yo, $texto, $fecha, $privacidad);
            $st->execute();
            $idNueva = $con->insert_id;
            $st->close();

            // Si tenía foto, guardamos la ruta en Multimedia
            if ($imagen != "") {
                $st = $con->prepare("INSERT INTO Multimedia (ID_Publicacion, URL, TipoArchivo) VALUES (?, ?, 'Imagen')");
                $st->bind_param("is", $idNueva, $imagen);
                $st->execute();
                $st->close();
            }

            header("Location: inicio.php");
            exit;
        }
    }
}

// Traemos las publicaciones que el usuario puede ver:
// las suyas, las públicas y las de "Amigos" si es amigo del que publicó
$st = $con->prepare("SELECT Publicaciones.ID_Publicacion, Publicaciones.Texto, Publicaciones.FechaPublicacion, Publicaciones.Privacidad,
        Perfiles.NombreUsuario, FotoPerfil.URL AS FotoAutor,
        (SELECT Multimedia.URL FROM Multimedia WHERE Multimedia.ID_Publicacion = Publicaciones.ID_Publicacion LIMIT 1) AS Imagen,
        (SELECT COUNT(*) FROM Interacciones WHERE Interacciones.ID_Publicacion = Publicaciones.ID_Publicacion) AS CantLikes,
        (SELECT COUNT(*) FROM Comentarios WHERE Comentarios.ID_Publicacion = Publicaciones.ID_Publicacion) AS CantComentarios,
        (SELECT COUNT(*) FROM Interacciones WHERE Interacciones.ID_Publicacion = Publicaciones.ID_Publicacion AND Interacciones.ID_Usuario = ?) AS YaLike
    FROM Publicaciones
    JOIN Usuarios ON Usuarios.ID_Usuario = Publicaciones.ID_Usuario
    JOIN Perfiles ON Perfiles.ID_Usuario = Publicaciones.ID_Usuario
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Usuarios.Estado = 'Activo' AND (
        Publicaciones.ID_Usuario = ?
        OR Publicaciones.Privacidad = 'Pública'
        OR (Publicaciones.Privacidad = 'Amigos' AND (
            Publicaciones.ID_Usuario IN (SELECT Amigos.ID_UsuarioAmigo FROM Amigos WHERE Amigos.ID_Usuario = ? AND Amigos.Estado = 'Aceptado')
            OR Publicaciones.ID_Usuario IN (SELECT Amigos.ID_Usuario FROM Amigos WHERE Amigos.ID_UsuarioAmigo = ? AND Amigos.Estado = 'Aceptado')
        ))
    )
    ORDER BY Publicaciones.FechaPublicacion DESC");
$st->bind_param("iiii", $yo, $yo, $yo, $yo);
$st->execute();
$publicaciones = $st->get_result();

$titulo = "Inicio";
$css = "inicio.css";
$activa = "inicio";
include "../general/arriba.php";
?>

<h4 class="fw-bold mb-1">Tu día, tus conexiones</h4>
<p class="text-muted small mb-4">Mirá lo último que compartieron tus amigos.</p>

<?php if ($msg != "") { ?>
  <div class="alert alert-warning small"><?php echo $msg; ?></div>
<?php } ?>

<!-- Caja para escribir una publicación nueva -->
<div class="card border-0 shadow-sm mb-4 crear-post">
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="accion" value="publicar">

      <div class="d-flex gap-2 mb-3">
        <?php mostrarAvatar($miFoto, "md"); ?>
        <textarea class="form-control bg-light border-0" name="texto" rows="2" maxlength="255" placeholder="¿Qué estás pensando, <?php echo htmlspecialchars($miNombre); ?>?"></textarea>
      </div>

      <div class="d-flex flex-wrap gap-2 align-items-center">
        <!-- Elegir foto -->
        <input type="file" class="form-control form-control-sm elegir-foto" name="foto" accept="image/jpeg,image/png">
        <!-- Quién puede verlo -->
        <select class="form-select form-select-sm w-auto bg-light border-0" name="privacidad">
          <option value="Pública">Pública</option>
          <option value="Amigos">Amigos</option>
          <option value="Privada">Privada</option>
        </select>
        <button type="submit" class="btn btn-primary btn-sm px-4 ms-auto">Publicar</button>
      </div>
    </form>
  </div>
</div>

<h6 class="text-muted text-uppercase fw-semibold chiquito mb-3">Publicaciones recientes</h6>

<!-- Lista de publicaciones -->
<?php
if ($publicaciones->num_rows == 0) {
    echo '<p class="text-muted small">Todavía no hay publicaciones.</p>';
}
while ($publicacion = $publicaciones->fetch_assoc()) {
    include "../general/post.php";
}
?>

<?php include "../general/abajo.php"; ?>
