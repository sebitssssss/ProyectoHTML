<?php
session_start();
include "../conexion.php";

$msg = "";

// Mensajes que llegan desde otras páginas
if (isset($_GET["registrado"])) {
    $msg = "Cuenta creada. Ya podés iniciar sesión.";
}

// Cuando se aprieta "Ingresar"
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $clave = $_POST["clave"];

    // Buscamos al usuario por el email
    $st = $con->prepare("SELECT Usuarios.ID_Usuario, Usuarios.`Contraseña`, Usuarios.Estado FROM Usuarios WHERE Usuarios.Email = ?");
    $st->bind_param("s", $email);
    $st->execute();
    $st->bind_result($id, $hash, $estado);

    if ($st->fetch() && password_verify($clave, $hash)) {
        $st->close();

        if ($estado == "Suspendido") {
            $msg = "Tu cuenta está suspendida.";
        } else {
            // Si la cuenta estaba desactivada, se vuelve a activar al entrar
            if ($estado == "Inactivo") {
                $st = $con->prepare("UPDATE Usuarios SET Usuarios.Estado = 'Activo' WHERE Usuarios.ID_Usuario = ?");
                $st->bind_param("i", $id);
                $st->execute();
                $st->close();
            }

            // Guardamos el id en la sesión y entramos
            session_regenerate_id(true);
            $_SESSION["id"] = $id;
            header("Location: ../inicio/inicio.php");
            exit;
        }
    } else {
        $st->close();
        $msg = "Email o contraseña incorrectos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar sesión - Fakebook</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="../general/general.css">
  <link rel="stylesheet" href="login.css">
</head>
<body>

  <div class="container-fluid p-0">
    <div class="row g-0 pantalla-completa">

      <!-- Lado izquierdo: foto con la frase (en el celular no se ve) -->
      <div class="col-md-6 d-none d-md-flex portada-login text-white p-5 flex-column justify-content-end">
        <h1 class="fw-bold">La vida es mejor cuando la compartís.</h1>
        <p class="text-white-50">Conectá con tus amigos, descubrí nuevas personas y compartí lo que te inspira.</p>
      </div>

      <!-- Lado derecho: formulario -->
      <div class="col-md-6 d-flex align-items-center justify-content-center p-4 bg-white">
        <div class="caja-form">
          <span class="logo"><i class="bi bi-triangle-fill"></i></span>
          <h2 class="fw-bold fs-4 mt-4 mb-1">Qué bueno verte de nuevo</h2>
          <p class="text-muted small mb-4">Ingresá a tu cuenta para seguir compartiendo.</p>

          <?php if ($msg != "") { ?>
            <div class="alert alert-info small py-2"><?php echo $msg; ?></div>
          <?php } ?>

          <form method="post">
            <div class="mb-3">
              <label class="form-label small fw-semibold">Email</label>
              <input type="email" class="form-control" name="email" maxlength="100" placeholder="tuemail@gmail.com" required>
            </div>
            <div class="mb-4">
              <label class="form-label small fw-semibold">Contraseña</label>
              <input type="password" class="form-control" name="clave" placeholder="Tu contraseña" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold mb-4">Ingresar</button>
          </form>

          <p class="text-muted small text-center mb-2">¿Todavía no tenés cuenta?</p>
          <a href="../registro/registro.php" class="btn btn-outline-secondary w-100 py-2 fw-semibold">Crear cuenta</a>
        </div>
      </div>

    </div>
  </div>

</body>
</html>
