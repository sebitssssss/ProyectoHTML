<?php
include "../general/sesion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idSolicitud = $_POST["id_amigo"];

    // Aceptar: la solicitud pasa a estar "Aceptado"
    if ($_POST["accion"] == "aceptar") {
        $hoy = date("Y-m-d");
        $st = $con->prepare("UPDATE Amigos SET Amigos.Estado = 'Aceptado', Amigos.FechaAlta = ? WHERE Amigos.ID_Amigo = ? AND Amigos.ID_UsuarioAmigo = ?");
        $st->bind_param("sii", $hoy, $idSolicitud, $yo);
        $st->execute();
        $st->close();
    }

    // Rechazar: borramos la solicitud
    if ($_POST["accion"] == "rechazar") {
        $st = $con->prepare("DELETE FROM Amigos WHERE Amigos.ID_Amigo = ? AND Amigos.ID_UsuarioAmigo = ?");
        $st->bind_param("ii", $idSolicitud, $yo);
        $st->execute();
        $st->close();
    }

    header("Location: solicitudes-recibidas.php");
    exit;
}

// Solicitudes pendientes que me mandaron a mí
$st = $con->prepare("SELECT Amigos.ID_Amigo, Amigos.FechaAlta, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto
    FROM Amigos
    JOIN Perfiles ON Perfiles.ID_Usuario = Amigos.ID_Usuario
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Amigos.ID_UsuarioAmigo = ? AND Amigos.Estado = 'Pendiente'");
$st->bind_param("i", $yo);
$st->execute();
$solicitudes = $st->get_result();

$titulo = "Solicitudes recibidas";
$css = "solicitudes-recibidas.css";
$activa = "amigos";
include "../general/arriba.php";
?>

<h4 class="fw-bold mb-1">Amigos</h4>
<p class="text-muted small mb-4">Las personas con las que compartís tu día a día.</p>

<div class="card border-0 shadow-sm">
  <div class="card-body p-4">
    <?php
    $tab = "recibidas";
    include "../general/tabs-amigos.php";
    ?>

    <div class="row g-3">
      <?php if ($solicitudes->num_rows == 0) { ?>
        <p class="text-muted small mb-0">No tenés solicitudes pendientes.</p>
      <?php } ?>

      <!-- Una tarjeta por cada solicitud -->
      <?php while ($solicitud = $solicitudes->fetch_assoc()) { ?>
        <div class="col-sm-6 col-lg-4">
          <div class="tarjeta-persona">
            <?php mostrarAvatar($solicitud["Foto"], "lg"); ?>
            <h6 class="fw-bold mt-3 mb-0"><?php echo htmlspecialchars($solicitud["NombreUsuario"]); ?></h6>
            <small class="text-muted d-block mb-2">Te la envió el <?php echo date("d/m/Y", strtotime($solicitud["FechaAlta"])); ?></small>
            <span class="badge bg-warning-subtle text-warning-emphasis mb-3">Pendiente</span>

            <!-- Los dos botones mandan el mismo formulario con distinta acción -->
            <form method="post" class="d-flex gap-2">
              <input type="hidden" name="id_amigo" value="<?php echo $solicitud["ID_Amigo"]; ?>">
              <button type="submit" name="accion" value="aceptar" class="btn btn-primary btn-sm">Aceptar</button>
              <button type="submit" name="accion" value="rechazar" class="btn btn-outline-secondary btn-sm">Rechazar</button>
            </form>
          </div>
        </div>
      <?php } ?>
    </div>
  </div>
</div>

<?php include "../general/abajo.php"; ?>
