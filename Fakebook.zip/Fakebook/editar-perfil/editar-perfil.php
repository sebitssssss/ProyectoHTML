<?php
include "../general/sesion.php";

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Guardar nombre, biografía, fecha de nacimiento y país
    if ($_POST["accion"] == "datos") {
        $nombre = trim($_POST["nombre"]);
        $biografia = trim($_POST["biografia"]);
        $nacimiento = $_POST["nacimiento"];
        $pais = $_POST["pais"];

        if ($nacimiento == "") {
            $nacimiento = null;
        }

        // Revisamos que el nombre no lo tenga otro usuario
        $st = $con->prepare("SELECT COUNT(*) FROM Perfiles WHERE Perfiles.NombreUsuario = ? AND Perfiles.ID_Usuario <> ?");
        $st->bind_param("si", $nombre, $yo);
        $st->execute();
        $st->bind_result($nombreUsado);
        $st->fetch();
        $st->close();

        if (strlen($nombre) < 3) {
            $msg = "El nombre de usuario tiene que tener al menos 3 caracteres.";
        } elseif ($nombreUsado > 0) {
            $msg = "Ese nombre de usuario ya existe.";
        } else {
            $st = $con->prepare("UPDATE Perfiles SET Perfiles.NombreUsuario = ?, Perfiles.Biografia = ?, Perfiles.FechaNacimiento = ?, Perfiles.ID_Pais = ? WHERE Perfiles.ID_Usuario = ?");
            $st->bind_param("sssii", $nombre, $biografia, $nacimiento, $pais, $yo);
            $st->execute();
            $st->close();

            header("Location: ../perfil/perfil.php");
            exit;
        }
    }

    // Subir una foto de perfil nueva
    if ($_POST["accion"] == "foto") {
        $ruta = subirImagen($_FILES["foto"], "perfiles");

        if ($ruta == "") {
            $msg = "La foto tiene que ser JPG o PNG y pesar menos de 5 MB.";
        } else {
            // Guardamos la foto en la tabla FotoPerfil
            $archivo = basename($ruta);
            $hoy = date("Y-m-d");
            $st = $con->prepare("INSERT INTO FotoPerfil (URL, Archivo, FechaSubida) VALUES (?, ?, ?)");
            $st->bind_param("sss", $ruta, $archivo, $hoy);
            $st->execute();
            $idFoto = $con->insert_id;
            $st->close();

            // Y se la asignamos al perfil
            $st = $con->prepare("UPDATE Perfiles SET Perfiles.ID_FotoPerfil = ? WHERE Perfiles.ID_Usuario = ?");
            $st->bind_param("ii", $idFoto, $yo);
            $st->execute();
            $st->close();

            header("Location: editar-perfil.php");
            exit;
        }
    }

    // Quitar la foto de perfil
    if ($_POST["accion"] == "quitar_foto") {
        $st = $con->prepare("UPDATE Perfiles SET Perfiles.ID_FotoPerfil = NULL WHERE Perfiles.ID_Usuario = ?");
        $st->bind_param("i", $yo);
        $st->execute();
        $st->close();

        header("Location: editar-perfil.php");
        exit;
    }
}

// Datos actuales para llenar el formulario
$st = $con->prepare("SELECT Perfiles.Biografia, Perfiles.FechaNacimiento, Perfiles.ID_Pais FROM Perfiles WHERE Perfiles.ID_Usuario = ?");
$st->bind_param("i", $yo);
$st->execute();
$st->bind_result($biografia, $nacimiento, $miPais);
$st->fetch();
$st->close();

$paises = $con->query("SELECT Paises.ID_Pais, Paises.Nombre FROM Paises ORDER BY Paises.Nombre");

$titulo = "Editar perfil";
$css = "editar-perfil.css";
$activa = "perfil";
include "../general/arriba.php";
?>

<div class="d-flex justify-content-between align-items-start mb-4">
  <div>
    <h4 class="fw-bold mb-1">Editar perfil</h4>
    <p class="text-muted small mb-0">Tu perfil, a tu manera. Elegí cómo querés presentarte.</p>
  </div>
  <a href="../perfil/perfil.php" class="btn btn-outline-secondary btn-sm">Volver al perfil</a>
</div>

<?php if ($msg != "") { ?>
  <div class="alert alert-danger small"><?php echo $msg; ?></div>
<?php } ?>

<div class="row g-3">

  <!-- Formulario con los datos -->
  <div class="col-lg-7">
    <div class="card border-0 shadow-sm p-4">
      <h6 class="fw-bold mb-3">Información personal</h6>
      <form method="post">
        <input type="hidden" name="accion" value="datos">

        <div class="mb-3">
          <label class="form-label small fw-semibold">Nombre de usuario</label>
          <input type="text" class="form-control" name="nombre" maxlength="30" value="<?php echo htmlspecialchars($miNombre); ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label small fw-semibold">Biografía</label>
          <textarea class="form-control" name="biografia" rows="3" maxlength="255"><?php echo htmlspecialchars($biografia); ?></textarea>
        </div>

        <div class="row g-3 mb-4">
          <div class="col-sm-6">
            <label class="form-label small fw-semibold">Fecha de nacimiento</label>
            <input type="date" class="form-control" name="nacimiento" value="<?php echo $nacimiento; ?>">
          </div>
          <div class="col-sm-6">
            <label class="form-label small fw-semibold">País</label>
            <select class="form-select" name="pais">
              <?php while ($pais = $paises->fetch_assoc()) { ?>
                <option value="<?php echo $pais["ID_Pais"]; ?>" <?php if ($pais["ID_Pais"] == $miPais) echo "selected"; ?>>
                  <?php echo $pais["Nombre"]; ?>
                </option>
              <?php } ?>
            </select>
          </div>
        </div>

        <div class="text-end">
          <a href="../perfil/perfil.php" class="btn btn-outline-secondary btn-sm">Cancelar</a>
          <button type="submit" class="btn btn-primary btn-sm">Guardar cambios</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Foto de perfil -->
  <div class="col-lg-5">
    <div class="card border-0 shadow-sm p-4 text-center">
      <h6 class="fw-bold mb-3 text-start">Foto de perfil</h6>
      <div class="mb-3"><?php mostrarAvatar($miFoto, "xl"); ?></div>

      <!-- Solo aparece si tiene foto -->
      <?php if ($miFoto != "") { ?>
        <form method="post" class="mb-3">
          <input type="hidden" name="accion" value="quitar_foto">
          <button type="submit" class="btn btn-link btn-sm text-muted">Quitar foto</button>
        </form>
      <?php } ?>

      <form method="post" enctype="multipart/form-data" class="text-start border-top pt-3">
        <input type="hidden" name="accion" value="foto">
        <label class="form-label small fw-semibold">Subir una foto nueva</label>
        <input type="file" class="form-control form-control-sm mb-1" name="foto" accept="image/jpeg,image/png" required>
        <small class="text-muted chiquito d-block mb-3">JPG o PNG. Hasta 5 MB.</small>
        <button type="submit" class="btn btn-primary btn-sm w-100">Guardar foto</button>
      </form>
    </div>
  </div>

</div>

<?php include "../general/abajo.php"; ?>
