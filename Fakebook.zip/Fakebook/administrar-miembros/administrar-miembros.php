<?php
include "../general/sesion.php";

if (!isset($_GET["id"])) {
    header("Location: ../grupos/grupos.php");
    exit;
}
$idGrupo = $_GET["id"];

// Mi rol en el grupo. Solo pueden entrar el fundador (5) y los administradores (1)
$miRol = 0;
$st = $con->prepare("SELECT Grupos_Usuarios.ID_Rol FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Grupo = ? AND Grupos_Usuarios.ID_Usuario = ?");
$st->bind_param("ii", $idGrupo, $yo);
$st->execute();
$st->bind_result($miRol);
$st->fetch();
$st->close();

if ($miRol != 5 && $miRol != 1) {
    header("Location: ../grupos/grupos.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idUsuario = $_POST["id_usuario"];

    // Cambiar el rol de un miembro (solo Administrador, Moderador o Miembro, y al fundador no se le puede cambiar)
    if ($_POST["accion"] == "rol" && $_POST["rol"] >= 1 && $_POST["rol"] <= 3) {
        $st = $con->prepare("UPDATE Grupos_Usuarios SET Grupos_Usuarios.ID_Rol = ? WHERE Grupos_Usuarios.ID_Grupo = ? AND Grupos_Usuarios.ID_Usuario = ? AND Grupos_Usuarios.ID_Rol <> 5");
        $st->bind_param("iii", $_POST["rol"], $idGrupo, $idUsuario);
        $st->execute();
        $st->close();
    }

    // Expulsar a un miembro (al fundador no se lo puede expulsar)
    if ($_POST["accion"] == "expulsar") {
        $st = $con->prepare("DELETE FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Grupo = ? AND Grupos_Usuarios.ID_Usuario = ? AND Grupos_Usuarios.ID_Rol <> 5");
        $st->bind_param("ii", $idGrupo, $idUsuario);
        $st->execute();
        $st->close();
    }

    header("Location: administrar-miembros.php?id=" . $idGrupo);
    exit;
}

// Nombre del grupo
$st = $con->prepare("SELECT Grupos.Nombre FROM Grupos WHERE Grupos.ID_Grupo = ?");
$st->bind_param("i", $idGrupo);
$st->execute();
$st->bind_result($nombreGrupo);
$st->fetch();
$st->close();

// Miembros del grupo
$st = $con->prepare("SELECT Perfiles.ID_Usuario, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto, Grupos_Usuarios.ID_Rol, RolesGrupo.Nombre AS Rol
    FROM Grupos_Usuarios
    JOIN Perfiles ON Perfiles.ID_Usuario = Grupos_Usuarios.ID_Usuario
    JOIN RolesGrupo ON RolesGrupo.ID_Rol = Grupos_Usuarios.ID_Rol
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Grupos_Usuarios.ID_Grupo = ?
    ORDER BY Grupos_Usuarios.FechaIngreso");
$st->bind_param("i", $idGrupo);
$st->execute();
$miembros = $st->get_result();

$titulo = "Administrar miembros";
$css = "administrar-miembros.css";
$activa = "grupos";
include "../general/arriba.php";
?>

<div class="d-flex justify-content-between align-items-start mb-4">
  <div>
    <h4 class="fw-bold mb-1"><?php echo htmlspecialchars($nombreGrupo); ?></h4>
    <p class="text-muted small mb-0">Administrar miembros</p>
  </div>
  <a href="../grupo/grupo.php?id=<?php echo $idGrupo; ?>" class="btn btn-outline-secondary btn-sm">Volver al grupo</a>
</div>

<div class="card border-0 shadow-sm">
  <div class="card-body p-4">

    <?php while ($miembro = $miembros->fetch_assoc()) { ?>
      <div class="d-flex flex-wrap align-items-center gap-3 py-3 border-bottom">
        <?php mostrarAvatar($miembro["Foto"], "sm"); ?>
        <span class="fw-semibold small me-auto"><?php echo htmlspecialchars($miembro["NombreUsuario"]); ?></span>

        <?php if ($miembro["ID_Rol"] == 5 || $miembro["ID_Usuario"] == $yo) { ?>
          <!-- Al fundador y a mí mismo no nos puedo cambiar nada -->
          <span class="badge rol"><?php echo $miembro["Rol"]; ?></span>
        <?php } else { ?>
          <!-- Elegir el rol nuevo y guardar -->
          <form method="post" class="d-flex gap-2">
            <input type="hidden" name="accion" value="rol">
            <input type="hidden" name="id_usuario" value="<?php echo $miembro["ID_Usuario"]; ?>">
            <select class="form-select form-select-sm elegir-rol" name="rol">
              <option value="1" <?php if ($miembro["ID_Rol"] == 1) echo "selected"; ?>>Administrador</option>
              <option value="2" <?php if ($miembro["ID_Rol"] == 2) echo "selected"; ?>>Moderador</option>
              <option value="3" <?php if ($miembro["ID_Rol"] == 3) echo "selected"; ?>>Miembro</option>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
          </form>

          <!-- Expulsar -->
          <form method="post">
            <input type="hidden" name="accion" value="expulsar">
            <input type="hidden" name="id_usuario" value="<?php echo $miembro["ID_Usuario"]; ?>">
            <button type="submit" class="btn btn-outline-danger btn-sm">Expulsar</button>
          </form>
        <?php } ?>
      </div>
    <?php } ?>

    <p class="text-muted chiquito mt-3 mb-0">Si expulsás a alguien, puede volver a unirse desde Grupos.</p>
  </div>
</div>

<?php include "../general/abajo.php"; ?>
