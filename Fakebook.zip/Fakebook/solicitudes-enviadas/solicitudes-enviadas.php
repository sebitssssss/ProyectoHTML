<?php
include "../general/sesion.php";

// Cancelar una solicitud que mandé
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["accion"] == "cancelar") {
    $st = $con->prepare("DELETE FROM Amigos WHERE Amigos.ID_Amigo = ? AND Amigos.ID_Usuario = ? AND Amigos.Estado = 'Pendiente'");
    $st->bind_param("ii", $_POST["id_amigo"], $yo);
    $st->execute();
    $st->close();

    header("Location: solicitudes-enviadas.php");
    exit;
}

// Solicitudes pendientes que mandé yo
$st = $con->prepare("SELECT Amigos.ID_Amigo, Amigos.FechaAlta, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto
    FROM Amigos
    JOIN Perfiles ON Perfiles.ID_Usuario = Amigos.ID_UsuarioAmigo
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Amigos.ID_Usuario = ? AND Amigos.Estado = 'Pendiente'");
$st->bind_param("i", $yo);
$st->execute();
$solicitudes = $st->get_result();

$titulo = "Solicitudes enviadas";
$css = "solicitudes-enviadas.css";
$activa = "amigos";
include "../general/arriba.php";
?>

<h4 class="fw-bold mb-1">Amigos</h4>
<p class="text-muted small mb-4">Las personas con las que compartís tu día a día.</p>

<div class="card border-0 shadow-sm">
  <div class="card-body p-4">
    <?php
    $tab = "enviadas";
    include "../general/tabs-amigos.php";
    ?>

    <div class="row g-3">
      <?php if ($solicitudes->num_rows == 0) { ?>
        <p class="text-muted small mb-0">No tenés solicitudes enviadas pendientes.</p>
      <?php } ?>

      <!-- Una tarjeta por cada solicitud -->
      <?php while ($solicitud = $solicitudes->fetch_assoc()) { ?>
        <div class="col-sm-6 col-lg-4">
          <div class="tarjeta-persona">
            <?php mostrarAvatar($solicitud["Foto"], "lg"); ?>
            <h6 class="fw-bold mt-3 mb-0"><?php echo htmlspecialchars($solicitud["NombreUsuario"]); ?></h6>
            <small class="text-muted d-block mb-2">Enviada el <?php echo date("d/m/Y", strtotime($solicitud["FechaAlta"])); ?></small>
            <span class="badge bg-warning-subtle text-warning-emphasis mb-3">Pendiente</span>
            <form method="post">
              <input type="hidden" name="accion" value="cancelar">
              <input type="hidden" name="id_amigo" value="<?php echo $solicitud["ID_Amigo"]; ?>">
              <button type="submit" class="btn btn-outline-secondary btn-sm">Cancelar solicitud</button>
            </form>
          </div>
        </div>
      <?php } ?>
    </div>
  </div>
</div>

<?php include "../general/abajo.php"; ?>
