<?php
include "../general/sesion.php";

// Si no viene el id de la publicación volvemos al inicio
if (!isset($_GET["id"])) {
    header("Location: ../inicio/inicio.php");
    exit;
}
$id = $_GET["id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Botón de Me gusta
    if ($_POST["accion"] == "like") {
        darLike($con, $yo, $id);
    }

    // Enviar un comentario
    if ($_POST["accion"] == "comentar") {
        $texto = trim($_POST["texto"]);
        if ($texto != "") {
            $fecha = date("Y-m-d H:i:s");
            $st = $con->prepare("INSERT INTO Comentarios (ID_Publicacion, ID_Usuario, Texto, Fecha) VALUES (?, ?, ?, ?)");
            $st->bind_param("iiss", $id, $yo, $texto, $fecha);
            $st->execute();
            $st->close();
        }
    }

    // Borrar un comentario (solo los propios)
    if ($_POST["accion"] == "borrar") {
        $st = $con->prepare("DELETE FROM Comentarios WHERE Comentarios.ID_Comentario = ? AND Comentarios.ID_Usuario = ?");
        $st->bind_param("ii", $_POST["id_comentario"], $yo);
        $st->execute();
        $st->close();
    }

    header("Location: publicacion.php?id=" . $id . "#comentarios");
    exit;
}

// Traemos la publicación (misma consulta que en inicio pero filtrando por id)
$st = $con->prepare("SELECT Publicaciones.ID_Publicacion, Publicaciones.Texto, Publicaciones.FechaPublicacion, Publicaciones.Privacidad,
        Perfiles.NombreUsuario, FotoPerfil.URL AS FotoAutor,
        (SELECT Multimedia.URL FROM Multimedia WHERE Multimedia.ID_Publicacion = Publicaciones.ID_Publicacion LIMIT 1) AS Imagen,
        (SELECT COUNT(*) FROM Interacciones WHERE Interacciones.ID_Publicacion = Publicaciones.ID_Publicacion) AS CantLikes,
        (SELECT COUNT(*) FROM Comentarios WHERE Comentarios.ID_Publicacion = Publicaciones.ID_Publicacion) AS CantComentarios,
        (SELECT COUNT(*) FROM Interacciones WHERE Interacciones.ID_Publicacion = Publicaciones.ID_Publicacion AND Interacciones.ID_Usuario = ?) AS YaLike
    FROM Publicaciones
    JOIN Perfiles ON Perfiles.ID_Usuario = Publicaciones.ID_Usuario
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Publicaciones.ID_Publicacion = ? AND (
        Publicaciones.ID_Usuario = ?
        OR Publicaciones.Privacidad = 'Pública'
        OR (Publicaciones.Privacidad = 'Amigos' AND (
            Publicaciones.ID_Usuario IN (SELECT Amigos.ID_UsuarioAmigo FROM Amigos WHERE Amigos.ID_Usuario = ? AND Amigos.Estado = 'Aceptado')
            OR Publicaciones.ID_Usuario IN (SELECT Amigos.ID_Usuario FROM Amigos WHERE Amigos.ID_UsuarioAmigo = ? AND Amigos.Estado = 'Aceptado')
        ))
    )");
$st->bind_param("iiiii", $yo, $id, $yo, $yo, $yo);
$st->execute();
$publicacion = $st->get_result()->fetch_assoc();
$st->close();

// Si no existe o no la puede ver, vuelve al inicio
if (!$publicacion) {
    header("Location: ../inicio/inicio.php");
    exit;
}

// Comentarios de la publicación
$st = $con->prepare("SELECT Comentarios.ID_Comentario, Comentarios.ID_Usuario, Comentarios.Texto, Comentarios.Fecha, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto
    FROM Comentarios
    JOIN Perfiles ON Perfiles.ID_Usuario = Comentarios.ID_Usuario
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Comentarios.ID_Publicacion = ?
    ORDER BY Comentarios.Fecha");
$st->bind_param("i", $id);
$st->execute();
$comentarios = $st->get_result();

// Personas que le dieron Me gusta
$st2 = $con->prepare("SELECT Perfiles.NombreUsuario, FotoPerfil.URL AS Foto
    FROM Interacciones
    JOIN Perfiles ON Perfiles.ID_Usuario = Interacciones.ID_Usuario
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Interacciones.ID_Publicacion = ?");
$st2->bind_param("i", $id);
$st2->execute();
$likes = $st2->get_result();

$titulo = "Publicación";
$css = "publicacion.css";
$activa = "inicio";
include "../general/arriba.php";
?>

<div class="d-flex justify-content-between align-items-start mb-4">
  <div>
    <h4 class="fw-bold mb-1">Publicación</h4>
    <p class="text-muted small mb-0">Mirá la publicación completa y sumate a la conversación.</p>
  </div>
  <a href="../inicio/inicio.php" class="btn btn-outline-secondary btn-sm">Volver al inicio</a>
</div>

<!-- La publicación -->
<?php include "../general/post.php"; ?>

<!-- Botón para ver quién dio Me gusta -->
<button type="button" class="btn btn-light btn-sm mb-4" data-bs-toggle="modal" data-bs-target="#modalLikes">
  <i class="bi bi-heart-fill text-danger"></i> Ver a quién le gusta
</button>

<!-- Comentarios -->
<div class="card border-0 shadow-sm" id="comentarios">
  <div class="card-body">
    <h6 class="fw-bold mb-3">Comentarios (<?php echo $comentarios->num_rows; ?>)</h6>

    <?php if ($comentarios->num_rows == 0) { ?>
      <p class="text-muted small">Nadie comentó todavía.</p>
    <?php } ?>

    <?php while ($comentario = $comentarios->fetch_assoc()) { ?>
      <div class="d-flex gap-2 mb-3">
        <?php mostrarAvatar($comentario["Foto"], "sm"); ?>
        <div>
          <div class="burbuja-comentario">
            <span class="fw-semibold small d-block"><?php echo htmlspecialchars($comentario["NombreUsuario"]); ?></span>
            <span class="small"><?php echo htmlspecialchars($comentario["Texto"]); ?></span>
          </div>
          <div class="d-flex gap-2 chiquito text-muted mt-1 ms-2">
            <span><?php echo date("d/m/Y H:i", strtotime($comentario["Fecha"])); ?></span>

            <!-- Si el comentario es mío puedo borrarlo -->
            <?php if ($comentario["ID_Usuario"] == $yo) { ?>
              <form method="post">
                <input type="hidden" name="accion" value="borrar">
                <input type="hidden" name="id_comentario" value="<?php echo $comentario["ID_Comentario"]; ?>">
                <button type="submit" class="btn-borrar">Borrar</button>
              </form>
            <?php } ?>
          </div>
        </div>
      </div>
    <?php } ?>

    <!-- Escribir un comentario nuevo -->
    <form method="post" class="d-flex gap-2 align-items-center border-top pt-3" id="comentar">
      <input type="hidden" name="accion" value="comentar">
      <?php mostrarAvatar($miFoto, "sm"); ?>
      <input type="text" class="form-control bg-light border-0" name="texto" maxlength="255" placeholder="Escribí un comentario..." required>
      <button type="submit" class="btn btn-primary btn-sm px-3">Enviar</button>
    </form>
  </div>
</div>

<!-- Ventana emergente con la lista de Me gusta -->
<div class="modal fade" id="modalLikes" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0">
      <div class="modal-header">
        <h6 class="modal-title fw-bold">Me gusta (<?php echo $likes->num_rows; ?>)</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <?php if ($likes->num_rows == 0) { ?>
          <p class="text-muted small mb-0">Todavía nadie le dio Me gusta.</p>
        <?php } ?>
        <?php while ($like = $likes->fetch_assoc()) { ?>
          <div class="d-flex align-items-center gap-2 mb-2">
            <?php mostrarAvatar($like["Foto"], "sm"); ?>
            <span class="small fw-semibold me-auto"><?php echo htmlspecialchars($like["NombreUsuario"]); ?></span>
            <i class="bi bi-heart-fill text-danger"></i>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
</div>

<?php include "../general/abajo.php"; ?>
