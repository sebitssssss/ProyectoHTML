DROP DATABASE IF EXISTS Red_Social;
CREATE DATABASE Red_Social CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE Red_Social;

CREATE TABLE Usuarios (
    ID_Usuario INT AUTO_INCREMENT PRIMARY KEY,
    Email VARCHAR(100) NOT NULL UNIQUE,
    `Contraseña` VARCHAR(255) NOT NULL,
    `2FA` BOOL NOT NULL DEFAULT 0,
    FechaRegistro DATE NOT NULL,
    Estado ENUM('Activo', 'Inactivo', 'Suspendido') NOT NULL DEFAULT 'Activo'
);

CREATE TABLE FotoPerfil (
    ID_FotoPerfil INT AUTO_INCREMENT PRIMARY KEY,
    URL VARCHAR(255) NOT NULL,
    Archivo VARCHAR(255) NOT NULL,
    FechaSubida DATE NOT NULL
);

CREATE TABLE Paises (
    ID_Pais INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE TiposInt (
    ID_TipoInt INT AUTO_INCREMENT PRIMARY KEY,
    Descripcion VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE TiposNotificacion (
    ID_TipoNotificacion INT AUTO_INCREMENT PRIMARY KEY,
    Descripcion VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE RolesGrupo (
    ID_Rol INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Perfiles (
    ID_Perfil INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NOT NULL UNIQUE,
    ID_FotoPerfil INT,
    ID_Pais INT,
    NombreUsuario VARCHAR(50) NOT NULL UNIQUE,
    Biografia VARCHAR(255),
    FechaNacimiento DATE,
    FOREIGN KEY (ID_Usuario) REFERENCES Usuarios(ID_Usuario),
    FOREIGN KEY (ID_FotoPerfil) REFERENCES FotoPerfil(ID_FotoPerfil),
    FOREIGN KEY (ID_Pais) REFERENCES Paises(ID_Pais)
);

CREATE TABLE Publicaciones (
    ID_Publicacion INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NOT NULL,
    Texto VARCHAR(255),
    FechaPublicacion DATETIME NOT NULL,
    Privacidad ENUM('Pública', 'Privada', 'Amigos') NOT NULL DEFAULT 'Pública',
    FOREIGN KEY (ID_Usuario) REFERENCES Usuarios(ID_Usuario)
);

CREATE TABLE Chats (
    ID_Chat INT AUTO_INCREMENT PRIMARY KEY,
    ID_UsuarioE INT NOT NULL,
    ID_UsuarioR INT NOT NULL,
    FechaCreacion DATE NOT NULL,
    FOREIGN KEY (ID_UsuarioE) REFERENCES Usuarios(ID_Usuario),
    FOREIGN KEY (ID_UsuarioR) REFERENCES Usuarios(ID_Usuario)
);

CREATE TABLE Amigos (
    ID_Amigo INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NOT NULL,
    ID_UsuarioAmigo INT NOT NULL,
    Estado ENUM('Pendiente', 'Aceptado', 'Bloqueado') NOT NULL DEFAULT 'Pendiente',
    FechaAlta DATE NOT NULL,
    FOREIGN KEY (ID_Usuario) REFERENCES Usuarios(ID_Usuario),
    FOREIGN KEY (ID_UsuarioAmigo) REFERENCES Usuarios(ID_Usuario)
);

CREATE TABLE Notificaciones (
    ID_Notificacion INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NOT NULL,
    ID_TipoNotificacion INT NOT NULL,
    Texto VARCHAR(255) NOT NULL,
    Fecha DATE NOT NULL,
    Leida BOOL NOT NULL DEFAULT 0,
    FOREIGN KEY (ID_Usuario) REFERENCES Usuarios(ID_Usuario),
    FOREIGN KEY (ID_TipoNotificacion) REFERENCES TiposNotificacion(ID_TipoNotificacion)
);

CREATE TABLE Grupos (
    ID_Grupo INT AUTO_INCREMENT PRIMARY KEY,
    `ID_Dueño` INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(255),
    FechaCreacion DATE NOT NULL,
    FOREIGN KEY (`ID_Dueño`) REFERENCES Usuarios(ID_Usuario)
);

CREATE TABLE Multimedia (
    ID_Multimedia INT AUTO_INCREMENT PRIMARY KEY,
    ID_Publicacion INT NOT NULL,
    URL VARCHAR(255) NOT NULL,
    TipoArchivo ENUM('Imagen', 'Video', 'Audio', 'Documento') NOT NULL,
    FOREIGN KEY (ID_Publicacion) REFERENCES Publicaciones(ID_Publicacion)
);

CREATE TABLE Comentarios (
    ID_Comentario INT AUTO_INCREMENT PRIMARY KEY,
    ID_Publicacion INT NOT NULL,
    ID_Usuario INT NOT NULL,
    Texto VARCHAR(255) NOT NULL,
    Fecha DATETIME NOT NULL,
    FOREIGN KEY (ID_Publicacion) REFERENCES Publicaciones(ID_Publicacion),
    FOREIGN KEY (ID_Usuario) REFERENCES Usuarios(ID_Usuario)
);

CREATE TABLE Interacciones (
    ID_Interaccion INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NOT NULL,
    ID_Publicacion INT NOT NULL,
    ID_TipoInt INT NOT NULL,
    Fecha DATETIME NOT NULL,
    UNIQUE (ID_Usuario, ID_Publicacion),
    FOREIGN KEY (ID_Usuario) REFERENCES Usuarios(ID_Usuario),
    FOREIGN KEY (ID_Publicacion) REFERENCES Publicaciones(ID_Publicacion),
    FOREIGN KEY (ID_TipoInt) REFERENCES TiposInt(ID_TipoInt)
);

CREATE TABLE Mensajes (
    ID_Mensaje INT AUTO_INCREMENT PRIMARY KEY,
    ID_Chat INT NOT NULL,
    ID_UsuarioEmisor INT NOT NULL,
    Texto VARCHAR(255) NOT NULL,
    FechaEnvio DATETIME NOT NULL,
    Leido BOOL NOT NULL DEFAULT 0,
    FOREIGN KEY (ID_Chat) REFERENCES Chats(ID_Chat),
    FOREIGN KEY (ID_UsuarioEmisor) REFERENCES Usuarios(ID_Usuario)
);

CREATE TABLE Grupos_Usuarios (
    ID_GrupoUsuario INT AUTO_INCREMENT PRIMARY KEY,
    ID_Grupo INT NOT NULL,
    ID_Usuario INT NOT NULL,
    ID_Rol INT NOT NULL,
    FechaIngreso DATE NOT NULL,
    UNIQUE (ID_Grupo, ID_Usuario),
    FOREIGN KEY (ID_Grupo) REFERENCES Grupos(ID_Grupo),
    FOREIGN KEY (ID_Usuario) REFERENCES Usuarios(ID_Usuario),
    FOREIGN KEY (ID_Rol) REFERENCES RolesGrupo(ID_Rol)
);


INSERT INTO Usuarios (Email, `Contraseña`, FechaRegistro, Estado) VALUES
('pulga@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-01', 'Activo'),
('dibu@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-03', 'Activo'),
('fideo@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-05', 'Activo'),
('kun@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-08', 'Inactivo'),
('suspendido@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-10', 'Suspendido'),
('julian@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-12', 'Activo'),
('cuti@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-14', 'Activo'),
('enzo@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-18', 'Activo'),
('lauti@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-09-25', 'Activo'),
('macalister@correo.com', '$2y$10$I8a0Y8ZlOsXyVPNRmYB65uZbzUoaDNo6M3fU9V9vJraLfAz9zLNre', '2026-10-02', 'Activo');

INSERT INTO Paises (Nombre) VALUES
('Argentina'),
('Chile'),
('Uruguay'),
('España'),
('México');

INSERT INTO TiposInt (Descripcion) VALUES
('Me gusta'),
('Me encanta'),
('Me divierte'),
('Me asombra'),
('Me entristece');

INSERT INTO TiposNotificacion (Descripcion) VALUES
('Nuevo comentario'),
('Nuevo me gusta'),
('Solicitud de amistad'),
('Nuevo mensaje'),
('Invitación a grupo');

INSERT INTO RolesGrupo (Nombre) VALUES
('Administrador'),
('Moderador'),
('Miembro'),
('Invitado'),
('Fundador');

INSERT INTO Perfiles (ID_Usuario, ID_FotoPerfil, ID_Pais, NombreUsuario, Biografia, FechaNacimiento) VALUES
(1, NULL, 1, 'pulga10', 'Rosarino. El 10 de la camiseta celeste y blanca.', '1987-06-24'),
(2, NULL, 1, 'dibu23', 'Arquero. Los penales son lo mío 🧤', '1992-09-02'),
(3, NULL, 1, 'fideo11', 'Zurdo de Rosario. Siempre con el corazón.', '1988-02-14'),
(4, NULL, 1, 'kun19', 'Ahora del otro lado de la cancha, mirando y comentando.', '1988-06-02'),
(5, NULL, 1, 'usuario_suspendido', 'Cuenta de prueba suspendida.', '2000-01-01'),
(6, NULL, 1, 'julian9', 'Delantero de Calchín. Corro todas.', '2000-01-31'),
(7, NULL, 1, 'cuti13', 'Defensor. Si pasa la pelota, no pasa el jugador.', '1998-04-27'),
(8, NULL, 1, 'enzo24', 'Mediocampista. Mate antes de cada partido.', '2001-01-17'),
(9, NULL, 1, 'lauti22', 'Toro. Goles y más goles.', '1997-08-22'),
(10, NULL, 1, 'macalister20', 'Volante. De familia futbolera.', '1998-12-24');

INSERT INTO Publicaciones (ID_Usuario, Texto, FechaPublicacion, Privacidad) VALUES
(1, 'Primer post en Fakebook. ¡Vamos Argentina! 🇦🇷', '2026-10-20 10:15:00', 'Pública'),
(2, 'Hoy practicamos penales toda la tarde 🧤', '2026-10-22 18:40:00', 'Pública'),
(3, 'Qué lindo volver al barrio y jugar un picado con los pibes.', '2026-10-24 21:05:00', 'Pública'),
(1, 'Asado con los muchachos el domingo, ¿quién se prende?', '2026-10-26 09:30:00', 'Amigos'),
(2, 'Recordatorio: llevar los guantes nuevos al entrenamiento.', '2026-10-28 16:00:00', 'Privada'),
(6, 'Doble turno de entrenamiento hoy. Las piernas ya no responden 😅', '2026-11-20 19:00:00', 'Pública'),
(8, 'Mate, factura y a la concentración.', '2026-11-22 08:30:00', 'Amigos');

INSERT INTO Chats (ID_UsuarioE, ID_UsuarioR, FechaCreacion) VALUES
(1, 2, '2026-10-01'),
(1, 3, '2026-10-02'),
(2, 3, '2026-10-03'),
(6, 1, '2026-11-10'),
(1, 7, '2026-11-15'),
(8, 1, '2026-11-20'),
(2, 6, '2026-11-18'),
(3, 8, '2026-11-19');

INSERT INTO Amigos (ID_Usuario, ID_UsuarioAmigo, Estado, FechaAlta) VALUES
(1, 2, 'Aceptado', '2026-09-15'),
(1, 3, 'Aceptado', '2026-09-16'),
(2, 3, 'Pendiente', '2026-09-20'),
(3, 4, 'Aceptado', '2026-09-22'),
(4, 5, 'Bloqueado', '2026-09-25'),
(1, 6, 'Aceptado', '2026-11-08'),
(7, 1, 'Aceptado', '2026-11-12'),
(1, 8, 'Aceptado', '2026-11-19'),
(9, 1, 'Pendiente', '2026-11-22'),
(1, 10, 'Pendiente', '2026-11-21'),
(2, 6, 'Aceptado', '2026-11-15'),
(2, 7, 'Aceptado', '2026-11-16'),
(3, 8, 'Aceptado', '2026-11-17'),
(10, 2, 'Pendiente', '2026-11-20');

INSERT INTO Grupos (`ID_Dueño`, Nombre, Descripcion, FechaCreacion) VALUES
(1, 'La Scaloneta', 'El grupo del plantel para organizarnos.', '2026-09-20'),
(2, 'Arqueros', 'Ejercicios, guantes y penales atajados.', '2026-09-21'),
(3, 'Picado de los jueves', 'Fútbol 5 todos los jueves a las 20.', '2026-09-22');

INSERT INTO Comentarios (ID_Publicacion, ID_Usuario, Texto, Fecha) VALUES
(1, 2, '¡Vamos capitán!', '2026-10-21 11:00:00'),
(1, 3, '🇦🇷🇦🇷🇦🇷', '2026-10-21 12:30:00'),
(2, 1, 'Atajaste todo, como siempre.', '2026-10-23 08:10:00'),
(3, 2, '¡Grande Fideo!', '2026-10-25 14:20:00'),
(3, 1, 'El barrio siempre tira.', '2026-10-25 15:45:00');

INSERT INTO Interacciones (ID_Usuario, ID_Publicacion, ID_TipoInt, Fecha) VALUES
(2, 1, 1, '2026-10-21 10:50:00'),
(3, 1, 1, '2026-10-21 12:25:00'),
(1, 2, 1, '2026-10-23 08:05:00'),
(1, 3, 1, '2026-10-25 15:40:00'),
(2, 3, 1, '2026-10-25 14:15:00'),
(1, 6, 1, '2026-11-20 19:30:00'),
(7, 6, 1, '2026-11-20 20:10:00');

INSERT INTO Mensajes (ID_Chat, ID_UsuarioEmisor, Texto, FechaEnvio, Leido) VALUES
(1, 1, 'Dibu, ¿cómo andás?', '2026-10-01 19:02:00', 1),
(1, 2, 'Bien, capi. ¿Y vos?', '2026-10-01 19:05:00', 1),
(2, 1, '¿Venís al entrenamiento de mañana?', '2026-10-02 17:30:00', 1),
(3, 3, 'Nos vemos mañana en el predio.', '2026-10-03 22:10:00', 1),
(1, 1, '¿Mañana hay que llevar la ropa de entrenamiento?', '2026-11-21 20:14:00', 1),
(1, 2, 'Sí, y los botines de tapones largos que la cancha está pesada.', '2026-11-21 20:20:00', 1),
(1, 1, 'Joya, gracias!', '2026-11-21 20:21:00', 1),
(1, 2, '¿Practicamos penales después del entrenamiento?', '2026-11-23 16:40:00', 0),
(1, 2, 'Te espero en el arco del fondo.', '2026-11-23 16:41:00', 0),
(2, 3, 'Sí, ahí voy. Llevo el mate.', '2026-10-02 18:05:00', 1),
(2, 1, 'Buenísimo, gracias Fideo.', '2026-10-02 18:07:00', 1),
(2, 3, '¿Vas al asado del domingo?', '2026-11-22 11:30:00', 1),
(2, 1, 'Obvio, llevo el vacío.', '2026-11-22 11:45:00', 1),
(4, 6, '¡Capi! Ya estoy en Fakebook 😄', '2026-11-10 15:00:00', 1),
(4, 1, 'Bienvenido Julián!', '2026-11-10 15:04:00', 1),
(4, 6, '¿Se pueden subir fotos?', '2026-11-10 15:06:00', 1),
(4, 1, 'Sí, desde el inicio, con el botón de Foto.', '2026-11-10 15:07:00', 1),
(4, 6, 'Genial, ahora subo las del entrenamiento.', '2026-11-23 17:30:00', 0),
(5, 1, 'Cuti, ¿jugamos el picado del jueves?', '2026-11-15 10:12:00', 1),
(5, 7, 'Obvio. ¿Vamos juntos?', '2026-11-15 10:30:00', 1),
(5, 1, 'Dale, te paso a buscar a las 19.', '2026-11-15 10:31:00', 1),
(5, 7, 'Qué partidazo ayer 🔥', '2026-11-17 09:02:00', 1),
(5, 1, 'Increíble el segundo gol.', '2026-11-17 09:10:00', 1),
(6, 8, 'Capi, ¿a qué hora es la charla técnica?', '2026-11-20 19:45:00', 1),
(6, 1, 'A las 10, en el salón del predio.', '2026-11-20 19:50:00', 1),
(6, 8, 'Perfecto. ¿Llevo algo?', '2026-11-23 18:02:00', 0),
(7, 2, 'Julián, ¿venís a la reunión del grupo?', '2026-11-18 14:00:00', 1),
(7, 6, 'Sí, llego 15 minutos tarde.', '2026-11-18 14:20:00', 0),
(8, 3, '¿Viste el video del partido?', '2026-11-19 21:10:00', 1),
(8, 8, 'Todavía no, mañana lo veo.', '2026-11-19 21:25:00', 1);

INSERT INTO Grupos_Usuarios (ID_Grupo, ID_Usuario, ID_Rol, FechaIngreso) VALUES
(1, 1, 5, '2026-09-20'),
(1, 2, 3, '2026-09-21'),
(1, 3, 2, '2026-09-23'),
(2, 2, 5, '2026-09-21'),
(2, 3, 3, '2026-09-22'),
(3, 3, 5, '2026-09-22');

INSERT INTO Notificaciones (ID_Usuario, ID_TipoNotificacion, Texto, Fecha, Leida) VALUES
(1, 1, 'dibu23 comentó tu publicación.', '2026-10-21', 1),
(1, 2, 'A fideo11 le gustó tu publicación.', '2026-10-21', 1),
(1, 3, 'lauti22 te envió una solicitud de amistad.', '2026-11-22', 0),
(1, 4, 'Tenés un nuevo mensaje de enzo24.', '2026-11-23', 0),
(2, 5, 'Te invitaron al grupo La Scaloneta.', '2026-09-21', 1);
