<?php
include "../general/sesion.php";

if (!isset($_GET["id"])) {
    header("Location: ../grupos/grupos.php");
    exit;
}
$idGrupo = $_GET["id"];

// Salir del grupo (el fundador no puede salir)
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["accion"] == "salir") {
    $st = $con->prepare("DELETE FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Grupo = ? AND Grupos_Usuarios.ID_Usuario = ? AND Grupos_Usuarios.ID_Rol <> 5");
    $st->bind_param("ii", $idGrupo, $yo);
    $st->execute();
    $st->close();

    header("Location: ../grupos/grupos.php");
    exit;
}

// Datos del grupo y quién es el dueño
$st = $con->prepare("SELECT Grupos.Nombre, Grupos.Descripcion, Grupos.FechaCreacion, Perfiles.NombreUsuario
    FROM Grupos
    JOIN Perfiles ON Perfiles.ID_Usuario = Grupos.`ID_Dueño`
    WHERE Grupos.ID_Grupo = ?");
$st->bind_param("i", $idGrupo);
$st->execute();
$st->bind_result($nombreGrupo, $descripcion, $fechaCreacion, $dueno);
$existe = $st->fetch();
$st->close();

if (!$existe) {
    header("Location: ../grupos/grupos.php");
    exit;
}

// Mi rol en el grupo (0 si no soy miembro)
$miRol = 0;
$st = $con->prepare("SELECT Grupos_Usuarios.ID_Rol FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Grupo = ? AND Grupos_Usuarios.ID_Usuario = ?");
$st->bind_param("ii", $idGrupo, $yo);
$st->execute();
$st->bind_result($miRol);
$st->fetch();
$st->close();

// Miembros del grupo con su rol
$st = $con->prepare("SELECT Perfiles.ID_Usuario, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto, RolesGrupo.Nombre AS Rol, Grupos_Usuarios.FechaIngreso
    FROM Grupos_Usuarios
    JOIN Perfiles ON Perfiles.ID_Usuario = Grupos_Usuarios.ID_Usuario
    JOIN RolesGrupo ON RolesGrupo.ID_Rol = Grupos_Usuarios.ID_Rol
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Grupos_Usuarios.ID_Grupo = ?
    ORDER BY Grupos_Usuarios.FechaIngreso");
$st->bind_param("i", $idGrupo);
$st->execute();
$miembros = $st->get_result();

$titulo = $nombreGrupo;
$css = "grupo.css";
$activa = "grupos";
include "../general/arriba.php";
?>

<div class="d-flex justify-content-between align-items-start mb-4">
  <div>
    <h4 class="fw-bold mb-1"><?php echo htmlspecialchars($nombreGrupo); ?></h4>
    <p class="text-muted small mb-0"><?php echo $miembros->num_rows; ?> miembros</p>
  </div>
  <a href="../grupos/grupos.php" class="btn btn-outline-secondary btn-sm">Volver a grupos</a>
</div>

<!-- Información del grupo -->
<div class="card border-0 shadow-sm mb-4">
  <div class="card-body p-4">
    <div class="row g-4 align-items-center">
      <div class="col-md-4 col-lg-3">
        <div class="portada-grupo color-<?php echo $idGrupo % 5; ?>"><?php echo mb_strtoupper(mb_substr($nombreGrupo, 0, 1)); ?></div>
      </div>
      <div class="col-md-8 col-lg-9">
        <p class="text-muted small mb-2"><?php echo htmlspecialchars($descripcion); ?></p>
        <p class="text-muted chiquito mb-3">
          Creado el <?php echo date("d/m/Y", strtotime($fechaCreacion)); ?> · Dueño: <?php echo htmlspecialchars($dueno); ?>
        </p>

        <!-- Si soy miembro (y no fundador) puedo salir -->
        <?php if ($miRol != 0 && $miRol != 5) { ?>
          <form method="post">
            <input type="hidden" name="accion" value="salir">
            <button type="submit" class="btn btn-outline-danger btn-sm">Salir del grupo</button>
          </form>
        <?php } ?>
      </div>
    </div>
  </div>
</div>

<!-- Lista de miembros -->
<div class="card border-0 shadow-sm">
  <div class="card-body p-4">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h6 class="fw-bold mb-0">Miembros</h6>
      <!-- Solo el fundador (5) y los administradores (1) ven este link -->
      <?php if ($miRol == 5 || $miRol == 1) { ?>
        <a href="../administrar-miembros/administrar-miembros.php?id=<?php echo $idGrupo; ?>" class="small fw-semibold">Administrar miembros</a>
      <?php } ?>
    </div>

    <?php while ($miembro = $miembros->fetch_assoc()) { ?>
      <div class="d-flex align-items-center gap-3 py-3 border-bottom">
        <?php mostrarAvatar($miembro["Foto"], "sm"); ?>
        <div class="me-auto">
          <span class="fw-semibold small d-block"><?php echo htmlspecialchars($miembro["NombreUsuario"]); ?></span>
          <small class="text-muted chiquito">Desde el <?php echo date("d/m/Y", strtotime($miembro["FechaIngreso"])); ?></small>
        </div>
        <span class="badge rol"><?php echo $miembro["Rol"]; ?></span>
      </div>
    <?php } ?>
  </div>
</div>

<?php include "../general/abajo.php"; ?>
