<?php
// Pestañas de Amigos / Solicitudes recibidas / Solicitudes enviadas
// Antes de incluirlo hay que definir $tab con la pestaña que está abierta

// Cantidad de amigos
$st = $con->prepare("SELECT COUNT(*) FROM Amigos WHERE Amigos.Estado = 'Aceptado' AND (Amigos.ID_Usuario = ? OR Amigos.ID_UsuarioAmigo = ?)");
$st->bind_param("ii", $yo, $yo);
$st->execute();
$st->bind_result($cantAmigos);
$st->fetch();
$st->close();

// Solicitudes que me mandaron
$st = $con->prepare("SELECT COUNT(*) FROM Amigos WHERE Amigos.Estado = 'Pendiente' AND Amigos.ID_UsuarioAmigo = ?");
$st->bind_param("i", $yo);
$st->execute();
$st->bind_result($cantRecibidas);
$st->fetch();
$st->close();

// Solicitudes que mandé yo
$st = $con->prepare("SELECT COUNT(*) FROM Amigos WHERE Amigos.Estado = 'Pendiente' AND Amigos.ID_Usuario = ?");
$st->bind_param("i", $yo);
$st->execute();
$st->bind_result($cantEnviadas);
$st->fetch();
$st->close();
?>
<ul class="nav nav-underline mb-4 pestanas">
  <li class="nav-item">
    <a class="nav-link <?php if ($tab == "amigos") echo "active"; ?>" href="../amigos/amigos.php">
      Mis amigos <span class="badge rounded-pill bg-light text-dark"><?php echo $cantAmigos; ?></span>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php if ($tab == "recibidas") echo "active"; ?>" href="../solicitudes-recibidas/solicitudes-recibidas.php">
      Solicitudes recibidas <span class="badge rounded-pill bg-light text-dark"><?php echo $cantRecibidas; ?></span>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php if ($tab == "enviadas") echo "active"; ?>" href="../solicitudes-enviadas/solicitudes-enviadas.php">
      Solicitudes enviadas <span class="badge rounded-pill bg-light text-dark"><?php echo $cantEnviadas; ?></span>
    </a>
  </li>
</ul>
