<?php
// Tarjeta de una publicación. Se usa en inicio, perfil y publicación.
// Antes de incluirlo tiene que existir $publicacion (una fila de la consulta)
$idPost = $publicacion["ID_Publicacion"];
?>
<article class="card border-0 shadow-sm mb-4 post" id="post-<?php echo $idPost; ?>">
  <div class="card-body">

    <!-- Quién lo publicó, cuándo y con qué privacidad -->
    <div class="d-flex align-items-center gap-2 mb-3">
      <?php mostrarAvatar($publicacion["FotoAutor"], "md"); ?>
      <div>
        <span class="fw-bold small d-block"><?php echo htmlspecialchars($publicacion["NombreUsuario"]); ?></span>
        <small class="text-muted chiquito">
          <?php echo date("d/m/Y H:i", strtotime($publicacion["FechaPublicacion"])); ?> ·
          <?php echo $publicacion["Privacidad"]; ?>
        </small>
      </div>
    </div>

    <!-- Texto de la publicación -->
    <?php if ($publicacion["Texto"] != "") { ?>
      <p class="texto-post"><?php echo htmlspecialchars($publicacion["Texto"]); ?></p>
    <?php } ?>

    <!-- Foto (si tiene) -->
    <?php if ($publicacion["Imagen"] != "") { ?>
      <img src="../<?php echo htmlspecialchars($publicacion["Imagen"]); ?>" class="foto-post mb-3" alt="">
    <?php } ?>

    <!-- Cantidad de likes y comentarios -->
    <div class="d-flex justify-content-between text-muted small border-bottom pb-2 mb-2">
      <a href="../publicacion/publicacion.php?id=<?php echo $idPost; ?>" class="text-muted">
        <i class="bi bi-heart-fill text-danger"></i> <?php echo $publicacion["CantLikes"]; ?> Me gusta
      </a>
      <a href="../publicacion/publicacion.php?id=<?php echo $idPost; ?>#comentarios" class="text-muted">
        <?php echo $publicacion["CantComentarios"]; ?> comentarios
      </a>
    </div>

    <!-- Botones de Me gusta y Comentar -->
    <div class="d-flex acciones">
      <form method="post" class="w-100">
        <input type="hidden" name="accion" value="like">
        <input type="hidden" name="id_publicacion" value="<?php echo $idPost; ?>">
        <?php if ($publicacion["YaLike"] > 0) { ?>
          <button type="submit" class="btn btn-sm w-100 border-0 con-like"><i class="bi bi-heart-fill"></i> Me gusta</button>
        <?php } else { ?>
          <button type="submit" class="btn btn-sm w-100 border-0"><i class="bi bi-heart"></i> Me gusta</button>
        <?php } ?>
      </form>
      <a href="../publicacion/publicacion.php?id=<?php echo $idPost; ?>#comentar" class="btn btn-sm w-100 border-0"><i class="bi bi-chat"></i> Comentar</a>
    </div>

  </div>
</article>
