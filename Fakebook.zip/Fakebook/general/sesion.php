<?php
// Se incluye al principio de todas las páginas donde hay que estar logueado
session_start();
include "../conexion.php";
include "../general/funciones.php";

// Si no inició sesión lo mandamos al login
if (!isset($_SESSION["id"])) {
    header("Location: ../login/login.php");
    exit;
}

$yo = $_SESSION["id"];

// Traemos el nombre de usuario y la foto del que está logueado
$st = $con->prepare("SELECT Perfiles.NombreUsuario, FotoPerfil.URL
                     FROM Perfiles
                     LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
                     WHERE Perfiles.ID_Usuario = ?");
$st->bind_param("i", $yo);
$st->execute();
$st->bind_result($miNombre, $miFoto);
$st->fetch();
$st->close();
?>
