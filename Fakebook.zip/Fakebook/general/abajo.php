          </div>
        </div>
      </main>

    </div>
  </div>

  <!-- Menú de abajo (solo se ve en el celular) -->
  <nav class="menu-celular fixed-bottom d-flex d-md-none">
    <a href="../inicio/inicio.php" class="<?php if ($activa == "inicio") echo "active"; ?>"><i class="bi bi-house-door"></i>Inicio</a>
    <a href="../amigos/amigos.php" class="<?php if ($activa == "amigos") echo "active"; ?>"><i class="bi bi-people"></i>Amigos</a>
    <a href="../mensajes/mensajes.php" class="<?php if ($activa == "mensajes") echo "active"; ?>"><i class="bi bi-chat-dots"></i>Mensajes</a>
    <a href="../grupos/grupos.php" class="<?php if ($activa == "grupos") echo "active"; ?>"><i class="bi bi-grid"></i>Grupos</a>
    <a href="../perfil/perfil.php" class="<?php if ($activa == "perfil") echo "active"; ?>"><i class="bi bi-person"></i>Perfil</a>
  </nav>

  <!-- JavaScript de Bootstrap (lo necesitan las ventanas emergentes) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
