<?php
// Muestra la foto de perfil, o un muñequito gris si no tiene foto
function mostrarAvatar($foto, $tamano)
{
    if ($foto != "") {
        echo '<img src="../' . htmlspecialchars($foto) . '" class="avatar avatar-' . $tamano . '" alt="">';
    } else {
        echo '<span class="avatar avatar-vacio avatar-' . $tamano . '"><i class="bi bi-person-fill"></i></span>';
    }
}

// Guarda la imagen subida en la carpeta uploads y devuelve la ruta
// Si hay algún problema devuelve "" (vacío)
function subirImagen($archivo, $carpeta)
{
    if ($archivo["error"] != 0) {
        return "";
    }

    // Solo dejamos JPG y PNG de hasta 5 MB
    $extension = strtolower(pathinfo($archivo["name"], PATHINFO_EXTENSION));
    if ($extension != "jpg" && $extension != "jpeg" && $extension != "png") {
        return "";
    }
    if ($archivo["size"] > 5 * 1024 * 1024) {
        return "";
    }

    // Si la carpeta no existe la creamos
    if (!is_dir("../uploads/" . $carpeta)) {
        mkdir("../uploads/" . $carpeta, 0755, true);
    }

    // Le ponemos un nombre nuevo para que no se pisen dos fotos con el mismo nombre
    $nombre = time() . "_" . rand(1000, 9999) . "." . $extension;
    $ruta = "uploads/" . $carpeta . "/" . $nombre;
    move_uploaded_file($archivo["tmp_name"], "../" . $ruta);

    return $ruta;
}

// Si el usuario ya le dio like a la publicación se lo saca, si no se lo pone
function darLike($con, $yo, $idPublicacion)
{
    $st = $con->prepare("SELECT COUNT(*) FROM Interacciones WHERE Interacciones.ID_Usuario = ? AND Interacciones.ID_Publicacion = ?");
    $st->bind_param("ii", $yo, $idPublicacion);
    $st->execute();
    $st->bind_result($yaTiene);
    $st->fetch();
    $st->close();

    if ($yaTiene > 0) {
        $st = $con->prepare("DELETE FROM Interacciones WHERE Interacciones.ID_Usuario = ? AND Interacciones.ID_Publicacion = ?");
        $st->bind_param("ii", $yo, $idPublicacion);
    } else {
        $fecha = date("Y-m-d H:i:s");
        $st = $con->prepare("INSERT INTO Interacciones (ID_Usuario, ID_Publicacion, ID_TipoInt, Fecha) VALUES (?, ?, 1, ?)");
        $st->bind_param("iis", $yo, $idPublicacion, $fecha);
    }
    $st->execute();
    $st->close();
}
?>
