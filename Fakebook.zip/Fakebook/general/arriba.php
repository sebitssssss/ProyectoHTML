<?php
// Parte de arriba de todas las páginas: head, barra de arriba y menú de la izquierda
// Antes de incluirlo hay que definir $titulo, $css y $activa

// Contamos los mensajes sin leer para mostrar el numerito en "Mensajes"
$st = $con->prepare("SELECT COUNT(*) FROM Mensajes
                     JOIN Chats ON Chats.ID_Chat = Mensajes.ID_Chat
                     WHERE (Chats.ID_UsuarioE = ? OR Chats.ID_UsuarioR = ?)
                     AND Mensajes.ID_UsuarioEmisor <> ? AND Mensajes.Leido = 0");
$st->bind_param("iii", $yo, $yo, $yo);
$st->execute();
$st->bind_result($sinLeer);
$st->fetch();
$st->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $titulo; ?> - Fakebook</title>
  <!-- Bootstrap y los íconos de Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Estilos que se usan en todas las páginas y los de esta página -->
  <link rel="stylesheet" href="../general/general.css">
  <link rel="stylesheet" href="<?php echo $css; ?>">
</head>
<body>

  <!-- Barra de arriba con el logo, el buscador y el usuario -->
  <nav class="navbar barra-arriba bg-white border-bottom sticky-top px-3">
    <div class="container-fluid gap-3 px-0">
      <a class="logo" href="../inicio/inicio.php"><i class="bi bi-triangle-fill"></i></a>

      <!-- El buscador manda a la página de amigos -->
      <form class="buscador d-none d-sm-block" action="../amigos/amigos.php" method="get">
        <input class="form-control border-0" type="search" name="buscar" placeholder="Buscar personas por nombre de usuario...">
      </form>

      <div class="ms-auto d-flex align-items-center gap-2">
        <a href="../perfil/perfil.php" class="d-flex align-items-center gap-2 text-dark">
          <span class="small fw-semibold d-none d-sm-inline"><?php echo htmlspecialchars($miNombre); ?></span>
          <?php mostrarAvatar($miFoto, "sm"); ?>
        </a>
        <a href="../logout/logout.php" class="btn btn-outline-danger btn-sm">Salir</a>
      </div>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row">

      <!-- Menú de la izquierda (en el celular no se ve) -->
      <aside class="col-md-3 col-lg-2 menu-lateral p-3 d-none d-md-block">
        <ul class="nav flex-column gap-1">
          <li><a class="nav-link <?php if ($activa == "inicio") echo "active"; ?>" href="../inicio/inicio.php"><i class="bi bi-house-door me-2"></i>Inicio</a></li>
          <li><a class="nav-link <?php if ($activa == "perfil") echo "active"; ?>" href="../perfil/perfil.php"><i class="bi bi-person me-2"></i>Perfil</a></li>
          <li><a class="nav-link <?php if ($activa == "amigos") echo "active"; ?>" href="../amigos/amigos.php"><i class="bi bi-people me-2"></i>Amigos</a></li>
          <li>
            <a class="nav-link d-flex align-items-center <?php if ($activa == "mensajes") echo "active"; ?>" href="../mensajes/mensajes.php">
              <i class="bi bi-chat-dots me-2"></i>Mensajes
              <?php if ($sinLeer > 0) { ?>
                <span class="badge rounded-pill bg-primary ms-auto"><?php echo $sinLeer; ?></span>
              <?php } ?>
            </a>
          </li>
          <li><a class="nav-link <?php if ($activa == "grupos") echo "active"; ?>" href="../grupos/grupos.php"><i class="bi bi-grid me-2"></i>Grupos</a></li>
          <li><a class="nav-link <?php if ($activa == "configuracion") echo "active"; ?>" href="../configuracion/configuracion.php"><i class="bi bi-gear me-2"></i>Configuración</a></li>
        </ul>
      </aside>

      <!-- Acá va el contenido de cada página -->
      <main class="col-md-9 col-lg-10 p-3 p-md-4 contenido">
        <div class="row justify-content-center">
          <div class="col-xl-9">
