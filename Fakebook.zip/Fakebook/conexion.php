<?php
// Hora de Argentina para todas las fechas (XAMPP por defecto usa la de Europa)
date_default_timezone_set("America/Argentina/Buenos_Aires");

$host    = "localhost";
$usuario = "root";
$clave   = "";
$bd      = "Red_Social";

$con = new mysqli($host, $usuario, $clave, $bd);

if ($con->connect_error) {
    die("Error de conexión: " . $con->connect_error);
}

$con->set_charset("utf8mb4");
?>
