<?php
include "../general/sesion.php";

// Botón de Me gusta en mis publicaciones
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["accion"] == "like") {
    darLike($con, $yo, $_POST["id_publicacion"]);
    header("Location: perfil.php#post-" . $_POST["id_publicacion"]);
    exit;
}

// Datos del perfil (biografía, país, fechas)
$st = $con->prepare("SELECT Perfiles.Biografia, Perfiles.FechaNacimiento, Paises.Nombre, Usuarios.FechaRegistro
    FROM Perfiles
    JOIN Usuarios ON Usuarios.ID_Usuario = Perfiles.ID_Usuario
    LEFT JOIN Paises ON Paises.ID_Pais = Perfiles.ID_Pais
    WHERE Perfiles.ID_Usuario = ?");
$st->bind_param("i", $yo);
$st->execute();
$st->bind_result($biografia, $nacimiento, $pais, $fechaRegistro);
$st->fetch();
$st->close();

// Estadísticas: cada número sale de contar en la base de datos
$st = $con->prepare("SELECT
    (SELECT COUNT(*) FROM Amigos WHERE Amigos.Estado = 'Aceptado' AND (Amigos.ID_Usuario = ? OR Amigos.ID_UsuarioAmigo = ?)),
    (SELECT COUNT(*) FROM Publicaciones WHERE Publicaciones.ID_Usuario = ?),
    (SELECT COUNT(*) FROM Interacciones JOIN Publicaciones ON Publicaciones.ID_Publicacion = Interacciones.ID_Publicacion WHERE Publicaciones.ID_Usuario = ?),
    (SELECT COUNT(*) FROM Comentarios JOIN Publicaciones ON Publicaciones.ID_Publicacion = Comentarios.ID_Publicacion WHERE Publicaciones.ID_Usuario = ?),
    (SELECT COUNT(*) FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Usuario = ?)");
$st->bind_param("iiiiii", $yo, $yo, $yo, $yo, $yo, $yo);
$st->execute();
$st->bind_result($cantAmigos, $cantPublicaciones, $cantLikes, $cantComentarios, $cantGrupos);
$st->fetch();
$st->close();

// Mis publicaciones
$st = $con->prepare("SELECT Publicaciones.ID_Publicacion, Publicaciones.Texto, Publicaciones.FechaPublicacion, Publicaciones.Privacidad,
        Perfiles.NombreUsuario, FotoPerfil.URL AS FotoAutor,
        (SELECT Multimedia.URL FROM Multimedia WHERE Multimedia.ID_Publicacion = Publicaciones.ID_Publicacion LIMIT 1) AS Imagen,
        (SELECT COUNT(*) FROM Interacciones WHERE Interacciones.ID_Publicacion = Publicaciones.ID_Publicacion) AS CantLikes,
        (SELECT COUNT(*) FROM Comentarios WHERE Comentarios.ID_Publicacion = Publicaciones.ID_Publicacion) AS CantComentarios,
        (SELECT COUNT(*) FROM Interacciones WHERE Interacciones.ID_Publicacion = Publicaciones.ID_Publicacion AND Interacciones.ID_Usuario = ?) AS YaLike
    FROM Publicaciones
    JOIN Perfiles ON Perfiles.ID_Usuario = Publicaciones.ID_Usuario
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Publicaciones.ID_Usuario = ?
    ORDER BY Publicaciones.FechaPublicacion DESC");
$st->bind_param("ii", $yo, $yo);
$st->execute();
$publicaciones = $st->get_result();

$titulo = "Mi perfil";
$css = "perfil.css";
$activa = "perfil";
include "../general/arriba.php";
?>

<!-- Tarjeta del perfil -->
<div class="card border-0 shadow-sm mb-4 overflow-hidden">
  <!-- Portada de color -->
  <div class="portada"></div>

  <div class="card-body pt-0 px-4">
    <!-- Foto de perfil y botón de editar -->
    <div class="d-flex justify-content-between align-items-end mb-3">
      <div class="foto-perfil"><?php mostrarAvatar($miFoto, "xl"); ?></div>
      <a href="../editar-perfil/editar-perfil.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-pencil"></i> Editar perfil</a>
    </div>

    <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($miNombre); ?></h5>
    <?php if ($biografia != "") { ?>
      <p class="small mb-2"><?php echo htmlspecialchars($biografia); ?></p>
    <?php } ?>

    <!-- País, cumpleaños y desde cuándo está -->
    <div class="d-flex flex-wrap gap-3 text-muted chiquito mb-3">
      <?php if ($pais != "") { ?>
        <span><i class="bi bi-geo-alt"></i> <?php echo $pais; ?></span>
      <?php } ?>
      <?php if ($nacimiento != "") { ?>
        <span><i class="bi bi-cake2"></i> Nació el <?php echo date("d/m/Y", strtotime($nacimiento)); ?></span>
      <?php } ?>
      <span><i class="bi bi-calendar3"></i> Se unió el <?php echo date("d/m/Y", strtotime($fechaRegistro)); ?></span>
    </div>

    <!-- Números del perfil -->
    <div class="row g-2 mb-1">
      <div class="col-6 col-sm-4 col-lg">
        <div class="estadistica"><strong><?php echo $cantAmigos; ?></strong><span>Amigos</span></div>
      </div>
      <div class="col-6 col-sm-4 col-lg">
        <div class="estadistica"><strong><?php echo $cantPublicaciones; ?></strong><span>Publicaciones</span></div>
      </div>
      <div class="col-6 col-sm-4 col-lg">
        <div class="estadistica"><strong><?php echo $cantLikes; ?></strong><span>Me gusta recibidos</span></div>
      </div>
      <div class="col-6 col-sm-4 col-lg">
        <div class="estadistica"><strong><?php echo $cantComentarios; ?></strong><span>Comentarios recibidos</span></div>
      </div>
      <div class="col-6 col-sm-4 col-lg">
        <div class="estadistica"><strong><?php echo $cantGrupos; ?></strong><span>Grupos</span></div>
      </div>
    </div>
  </div>
</div>

<h6 class="text-muted text-uppercase fw-semibold chiquito mb-3">Mis publicaciones</h6>

<!-- Lista de mis publicaciones -->
<?php
if ($publicaciones->num_rows == 0) {
    echo '<p class="text-muted small">Todavía no publicaste nada.</p>';
}
while ($publicacion = $publicaciones->fetch_assoc()) {
    include "../general/post.php";
}
?>

<?php include "../general/abajo.php"; ?>
