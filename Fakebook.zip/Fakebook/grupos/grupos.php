<?php
include "../general/sesion.php";

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Crear un grupo nuevo
    if ($_POST["accion"] == "crear") {
        $nombre = trim($_POST["nombre"]);
        $descripcion = trim($_POST["descripcion"]);
        $hoy = date("Y-m-d");

        if ($nombre == "") {
            $msg = "El grupo tiene que tener un nombre.";
        } else {
            $st = $con->prepare("INSERT INTO Grupos (`ID_Dueño`, Nombre, Descripcion, FechaCreacion) VALUES (?, ?, ?, ?)");
            $st->bind_param("isss", $yo, $nombre, $descripcion, $hoy);
            $st->execute();
            $idGrupo = $con->insert_id;
            $st->close();

            // El que crea el grupo entra como Fundador (rol 5)
            $st = $con->prepare("INSERT INTO Grupos_Usuarios (ID_Grupo, ID_Usuario, ID_Rol, FechaIngreso) VALUES (?, ?, 5, ?)");
            $st->bind_param("iis", $idGrupo, $yo, $hoy);
            $st->execute();
            $st->close();

            header("Location: ../grupo/grupo.php?id=" . $idGrupo);
            exit;
        }
    }

    // Unirse a un grupo (entra como Miembro, rol 3)
    if ($_POST["accion"] == "unirme") {
        $idGrupo = $_POST["id_grupo"];

        // Revisamos que no esté ya en el grupo
        $st = $con->prepare("SELECT COUNT(*) FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Grupo = ? AND Grupos_Usuarios.ID_Usuario = ?");
        $st->bind_param("ii", $idGrupo, $yo);
        $st->execute();
        $st->bind_result($yaEsta);
        $st->fetch();
        $st->close();

        if ($yaEsta == 0) {
            $hoy = date("Y-m-d");
            $st = $con->prepare("INSERT INTO Grupos_Usuarios (ID_Grupo, ID_Usuario, ID_Rol, FechaIngreso) VALUES (?, ?, 3, ?)");
            $st->bind_param("iis", $idGrupo, $yo, $hoy);
            $st->execute();
            $st->close();
        }

        header("Location: grupos.php");
        exit;
    }
}

// Todos los grupos, con la cantidad de miembros y si yo estoy adentro
$st = $con->prepare("SELECT Grupos.ID_Grupo, Grupos.Nombre, Grupos.Descripcion,
        (SELECT COUNT(*) FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Grupo = Grupos.ID_Grupo) AS CantMiembros,
        (SELECT COUNT(*) FROM Grupos_Usuarios WHERE Grupos_Usuarios.ID_Grupo = Grupos.ID_Grupo AND Grupos_Usuarios.ID_Usuario = ?) AS SoyMiembro
    FROM Grupos
    ORDER BY Grupos.Nombre");
$st->bind_param("i", $yo);
$st->execute();
$grupos = $st->get_result();

$titulo = "Grupos";
$css = "grupos.css";
$activa = "grupos";
include "../general/arriba.php";
?>

<div class="d-flex justify-content-between align-items-start mb-4">
  <div>
    <h4 class="fw-bold mb-1">Descubrí tu comunidad</h4>
    <p class="text-muted small mb-0">Sumate a grupos con tus intereses o creá el tuyo.</p>
  </div>
  <!-- Abre la ventana para crear un grupo -->
  <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalCrearGrupo"><i class="bi bi-plus-lg"></i> Crear grupo</button>
</div>

<?php if ($msg != "") { ?>
  <div class="alert alert-danger small"><?php echo $msg; ?></div>
<?php } ?>

<!-- Tarjetas de los grupos -->
<div class="row g-3">
  <?php while ($grupo = $grupos->fetch_assoc()) { ?>
    <div class="col-sm-6 col-lg-4">
      <div class="card border-0 shadow-sm h-100">
        <!-- Portada de color con la primera letra del nombre -->
        <div class="portada-grupo color-<?php echo $grupo["ID_Grupo"] % 5; ?>">
          <?php echo mb_strtoupper(mb_substr($grupo["Nombre"], 0, 1)); ?>
        </div>
        <div class="card-body d-flex flex-column">
          <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($grupo["Nombre"]); ?></h6>
          <p class="text-muted small mb-2"><?php echo htmlspecialchars($grupo["Descripcion"]); ?></p>
          <small class="text-muted chiquito mb-3"><i class="bi bi-people"></i> <?php echo $grupo["CantMiembros"]; ?> miembros</small>

          <!-- Si ya soy miembro puedo entrar, si no me puedo unir -->
          <?php if ($grupo["SoyMiembro"] > 0) { ?>
            <a href="../grupo/grupo.php?id=<?php echo $grupo["ID_Grupo"]; ?>" class="btn btn-outline-secondary btn-sm w-100 mt-auto">Ver grupo</a>
          <?php } else { ?>
            <form method="post" class="mt-auto">
              <input type="hidden" name="accion" value="unirme">
              <input type="hidden" name="id_grupo" value="<?php echo $grupo["ID_Grupo"]; ?>">
              <button type="submit" class="btn btn-primary btn-sm w-100">Unirme</button>
            </form>
          <?php } ?>
        </div>
      </div>
    </div>
  <?php } ?>
</div>

<!-- Ventana emergente para crear un grupo -->
<div class="modal fade" id="modalCrearGrupo" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0">
      <form method="post">
        <input type="hidden" name="accion" value="crear">
        <div class="modal-header">
          <h6 class="modal-title fw-bold">Crear grupo</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label small fw-semibold">Nombre</label>
            <input type="text" class="form-control" name="nombre" maxlength="100" required>
          </div>
          <div class="mb-2">
            <label class="form-label small fw-semibold">Descripción</label>
            <textarea class="form-control" name="descripcion" rows="3" maxlength="255"></textarea>
          </div>
          <small class="text-muted chiquito">Vas a quedar como fundador del grupo.</small>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-primary btn-sm">Crear grupo</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include "../general/abajo.php"; ?>
