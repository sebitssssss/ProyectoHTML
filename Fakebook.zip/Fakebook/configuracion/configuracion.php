<?php
include "../general/sesion.php";

$msg = "";
$tipoMsg = "danger";

// Datos de la cuenta
$st = $con->prepare("SELECT Usuarios.Email, Usuarios.`Contraseña`, Usuarios.FechaRegistro FROM Usuarios WHERE Usuarios.ID_Usuario = ?");
$st->bind_param("i", $yo);
$st->execute();
$st->bind_result($email, $hash, $fechaRegistro);
$st->fetch();
$st->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Cambiar el email
    if ($_POST["accion"] == "email") {
        $emailNuevo = trim($_POST["email"]);

        // Revisamos que no lo use otra cuenta
        $st = $con->prepare("SELECT COUNT(*) FROM Usuarios WHERE Usuarios.Email = ? AND Usuarios.ID_Usuario <> ?");
        $st->bind_param("si", $emailNuevo, $yo);
        $st->execute();
        $st->bind_result($usado);
        $st->fetch();
        $st->close();

        if ($usado > 0) {
            $msg = "Ese email ya lo usa otra cuenta.";
        } else {
            $st = $con->prepare("UPDATE Usuarios SET Usuarios.Email = ? WHERE Usuarios.ID_Usuario = ?");
            $st->bind_param("si", $emailNuevo, $yo);
            $st->execute();
            $st->close();
            $email = $emailNuevo;
            $msg = "Email actualizado.";
            $tipoMsg = "success";
        }
    }

    // Cambiar la contraseña
    if ($_POST["accion"] == "clave") {
        if (!password_verify($_POST["clave_actual"], $hash)) {
            $msg = "La contraseña actual no es correcta.";
        } elseif (strlen($_POST["clave_nueva"]) < 8) {
            $msg = "La contraseña nueva tiene que tener mínimo 8 caracteres.";
        } elseif ($_POST["clave_nueva"] != $_POST["clave_repetida"]) {
            $msg = "Las contraseñas nuevas no coinciden.";
        } else {
            $hashNuevo = password_hash($_POST["clave_nueva"], PASSWORD_DEFAULT);
            $st = $con->prepare("UPDATE Usuarios SET Usuarios.`Contraseña` = ? WHERE Usuarios.ID_Usuario = ?");
            $st->bind_param("si", $hashNuevo, $yo);
            $st->execute();
            $st->close();
            $msg = "Contraseña actualizada.";
            $tipoMsg = "success";
        }
    }
}

$titulo = "Configuración";
$css = "configuracion.css";
$activa = "configuracion";
include "../general/arriba.php";
?>

<h4 class="fw-bold mb-1">Configuración</h4>
<p class="text-muted small mb-4">Administrá la seguridad y los datos de tu cuenta.</p>

<?php if ($msg != "") { ?>
  <div class="alert alert-<?php echo $tipoMsg; ?> small"><?php echo $msg; ?></div>
<?php } ?>

<div class="row g-3">
  <div class="col-lg-8">

    <!-- Cambiar email -->
    <div class="card border-0 shadow-sm p-4 mb-3">
      <h6 class="fw-bold mb-3">Email</h6>
      <form method="post">
        <input type="hidden" name="accion" value="email">
        <label class="form-label small fw-semibold">Email de la cuenta</label>
        <input type="email" class="form-control mb-3" name="email" maxlength="100" value="<?php echo htmlspecialchars($email); ?>" required>
        <div class="text-end">
          <button type="submit" class="btn btn-primary btn-sm">Guardar email</button>
        </div>
      </form>
    </div>

    <!-- Cambiar contraseña -->
    <div class="card border-0 shadow-sm p-4">
      <h6 class="fw-bold mb-3">Cambiar contraseña</h6>
      <form method="post">
        <input type="hidden" name="accion" value="clave">
        <div class="mb-3">
          <label class="form-label small fw-semibold">Contraseña actual</label>
          <input type="password" class="form-control" name="clave_actual" required>
        </div>
        <div class="mb-3">
          <label class="form-label small fw-semibold">Nueva contraseña</label>
          <input type="password" class="form-control" name="clave_nueva" required>
        </div>
        <div class="mb-3">
          <label class="form-label small fw-semibold">Repetir nueva contraseña</label>
          <input type="password" class="form-control" name="clave_repetida" required>
        </div>
        <div class="text-end">
          <button type="submit" class="btn btn-primary btn-sm">Actualizar contraseña</button>
        </div>
      </form>
    </div>

  </div>

  <div class="col-lg-4">

    <!-- Datos de la cuenta -->
    <div class="card border-0 shadow-sm p-4 datos-cuenta">
      <h6 class="fw-bold mb-3">Tu cuenta</h6>
      <p class="chiquito text-muted mb-0">Usuario</p>
      <p class="small dato"><?php echo htmlspecialchars($miNombre); ?></p>
      <p class="chiquito text-muted mb-0">Miembro desde</p>
      <p class="small dato"><?php echo date("d/m/Y", strtotime($fechaRegistro)); ?></p>
    </div>

  </div>
</div>

<?php include "../general/abajo.php"; ?>
