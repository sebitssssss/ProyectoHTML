<?php
include "../general/sesion.php";

$buscar = "";
if (isset($_GET["buscar"])) {
    $buscar = trim($_GET["buscar"]);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $otro = $_POST["id_usuario"];

    // Mandar solicitud de amistad
    if ($_POST["accion"] == "agregar") {
        // Revisamos que no exista ya una solicitud o amistad entre los dos
        $st = $con->prepare("SELECT COUNT(*) FROM Amigos
            WHERE (Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?) OR (Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?)");
        $st->bind_param("iiii", $yo, $otro, $otro, $yo);
        $st->execute();
        $st->bind_result($yaExiste);
        $st->fetch();
        $st->close();

        if ($yaExiste == 0 && $otro != $yo) {
            $hoy = date("Y-m-d");
            $st = $con->prepare("INSERT INTO Amigos (ID_Usuario, ID_UsuarioAmigo, Estado, FechaAlta) VALUES (?, ?, 'Pendiente', ?)");
            $st->bind_param("iis", $yo, $otro, $hoy);
            $st->execute();
            $st->close();
        }
    }

    // Eliminar a un amigo
    if ($_POST["accion"] == "eliminar") {
        $st = $con->prepare("DELETE FROM Amigos WHERE Amigos.Estado = 'Aceptado'
            AND ((Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?) OR (Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?))");
        $st->bind_param("iiii", $yo, $otro, $otro, $yo);
        $st->execute();
        $st->close();
    }

    header("Location: amigos.php?buscar=" . urlencode($buscar));
    exit;
}

// Si escribió algo en el buscador, buscamos usuarios activos con ese nombre
if ($buscar != "") {
    $patron = "%" . $buscar . "%";
    $st = $con->prepare("SELECT Perfiles.ID_Usuario, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto
        FROM Perfiles
        JOIN Usuarios ON Usuarios.ID_Usuario = Perfiles.ID_Usuario
        LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
        WHERE Perfiles.NombreUsuario LIKE ? AND Perfiles.ID_Usuario <> ? AND Usuarios.Estado = 'Activo'
        ORDER BY Perfiles.NombreUsuario");
    $st->bind_param("si", $patron, $yo);
    $st->execute();
    $resultados = $st->get_result();
}

// Consulta para saber si ya hay solicitud o amistad con cada persona encontrada
$stRelacion = $con->prepare("SELECT Amigos.Estado FROM Amigos
    WHERE (Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?) OR (Amigos.ID_Usuario = ? AND Amigos.ID_UsuarioAmigo = ?)");

// Mis amigos (puedo estar guardado como ID_Usuario o como ID_UsuarioAmigo)
$st = $con->prepare("SELECT Perfiles.ID_Usuario, Perfiles.NombreUsuario, FotoPerfil.URL AS Foto, Amigos.FechaAlta
    FROM Amigos
    JOIN Perfiles ON (Perfiles.ID_Usuario = Amigos.ID_UsuarioAmigo AND Amigos.ID_Usuario = ?)
                  OR (Perfiles.ID_Usuario = Amigos.ID_Usuario AND Amigos.ID_UsuarioAmigo = ?)
    LEFT JOIN FotoPerfil ON FotoPerfil.ID_FotoPerfil = Perfiles.ID_FotoPerfil
    WHERE Amigos.Estado = 'Aceptado'
    ORDER BY Perfiles.NombreUsuario");
$st->bind_param("ii", $yo, $yo);
$st->execute();
$amigos = $st->get_result();

$titulo = "Amigos";
$css = "amigos.css";
$activa = "amigos";
include "../general/arriba.php";
?>

<h4 class="fw-bold mb-1">Amigos</h4>
<p class="text-muted small mb-4">Las personas con las que compartís tu día a día.</p>

<!-- Buscador de personas -->
<div class="card border-0 shadow-sm mb-4">
  <div class="card-body p-4">
    <h6 class="fw-bold mb-3">Buscar personas</h6>
    <form method="get" class="d-flex gap-2">
      <input type="search" class="form-control bg-light border-0" name="buscar" value="<?php echo htmlspecialchars($buscar); ?>" placeholder="Escribí un nombre de usuario...">
      <button type="submit" class="btn btn-primary px-4">Buscar</button>
    </form>

    <!-- Resultados de la búsqueda -->
    <?php if ($buscar != "") { ?>
      <div class="mt-3">
        <?php if ($resultados->num_rows == 0) { ?>
          <p class="text-muted small mb-0">No encontramos a nadie con ese nombre.</p>
        <?php } ?>

        <?php while ($persona = $resultados->fetch_assoc()) { ?>
          <?php
          // Vemos si ya son amigos o si hay una solicitud pendiente
          $relacion = "";
          $stRelacion->bind_param("iiii", $yo, $persona["ID_Usuario"], $persona["ID_Usuario"], $yo);
          $stRelacion->execute();
          $stRelacion->bind_result($relacion);
          $stRelacion->fetch();
          $stRelacion->free_result();
          ?>
          <div class="d-flex align-items-center gap-3 py-2 border-bottom">
            <?php mostrarAvatar($persona["Foto"], "sm"); ?>
            <span class="fw-semibold small me-auto"><?php echo htmlspecialchars($persona["NombreUsuario"]); ?></span>

            <?php if ($relacion == "Aceptado") { ?>
              <span class="badge bg-success-subtle text-success">Amigos</span>
            <?php } elseif ($relacion == "Pendiente") { ?>
              <span class="badge bg-warning-subtle text-warning-emphasis">Solicitud pendiente</span>
            <?php } elseif ($relacion == "Bloqueado") { ?>
              <span class="badge bg-danger-subtle text-danger">Bloqueado</span>
            <?php } else { ?>
              <form method="post">
                <input type="hidden" name="accion" value="agregar">
                <input type="hidden" name="id_usuario" value="<?php echo $persona["ID_Usuario"]; ?>">
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-person-plus"></i> Agregar</button>
              </form>
            <?php } ?>
          </div>
        <?php } ?>
      </div>
    <?php } ?>
  </div>
</div>

<!-- Lista de amigos -->
<div class="card border-0 shadow-sm">
  <div class="card-body p-4">
    <?php
    $tab = "amigos";
    include "../general/tabs-amigos.php";
    ?>

    <div class="row g-3">
      <?php if ($amigos->num_rows == 0) { ?>
        <p class="text-muted small mb-0">Todavía no tenés amigos. Buscá personas por su nombre de usuario.</p>
      <?php } ?>

      <?php while ($amigo = $amigos->fetch_assoc()) { ?>
        <div class="col-sm-6 col-lg-4">
          <div class="tarjeta-persona">
            <?php mostrarAvatar($amigo["Foto"], "lg"); ?>
            <h6 class="fw-bold mt-3 mb-0"><?php echo htmlspecialchars($amigo["NombreUsuario"]); ?></h6>
            <small class="text-muted d-block mb-3">Amigos desde el <?php echo date("d/m/Y", strtotime($amigo["FechaAlta"])); ?></small>
            <div class="d-flex gap-2">
              <a href="../mensajes/mensajes.php?con=<?php echo $amigo["ID_Usuario"]; ?>" class="btn btn-primary btn-sm">Enviar mensaje</a>
              <form method="post">
                <input type="hidden" name="accion" value="eliminar">
                <input type="hidden" name="id_usuario" value="<?php echo $amigo["ID_Usuario"]; ?>">
                <button type="submit" class="btn btn-outline-secondary btn-sm">Eliminar</button>
              </form>
            </div>
          </div>
        </div>
      <?php } ?>
    </div>
  </div>
</div>

<?php include "../general/abajo.php"; ?>
