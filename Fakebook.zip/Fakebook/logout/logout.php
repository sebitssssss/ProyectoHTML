<?php
// Cierra la sesión y vuelve al login
session_start();
session_destroy();
header("Location: ../login/login.php");
exit;
?>
